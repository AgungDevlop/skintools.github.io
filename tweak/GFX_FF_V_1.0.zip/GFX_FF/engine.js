const DB = {
    "vip": [
        { 
            name: "Auto Headshot Ultimate", 
            desc: "Sensitivitas ekstrem, 0 touch slop, pressure 0.001. Akurasi drag aim naik 200%.", 
            on: "setprop debug.graphics.game_default_frame_rate.disabled 1; settings put system game_scene_more_fps 1; settings put system gamewatch_game_target_fps 240; settings put global game_memc_request_touch_rate 1; setprop ro.input.scroll_friction 0.001; setprop view.scroll_friction 0.001; setprop view.touch_slop 0; settings put system touch.pressure.scale 0.001; settings put system touch.size.scale 0.001; settings put system pointer_speed 7; setprop windowsmgr.max_events_per_sec 9999; settings put global tap_duration_threshold 0; settings put secure long_press_timeout 100;", 
            off: "setprop debug.graphics.game_default_frame_rate.disabled 0; settings delete system game_scene_more_fps; settings delete system gamewatch_game_target_fps; settings delete global game_memc_request_touch_rate; setprop ro.input.scroll_friction 0.015; setprop view.scroll_friction 0.015; setprop view.touch_slop 8; settings delete system touch.pressure.scale; settings delete system touch.size.scale; settings put system pointer_speed 4; setprop windowsmgr.max_events_per_sec 90; settings delete global tap_duration_threshold; settings put secure long_press_timeout 400;" 
        },
        { 
            name: "Force HW Composition", 
            desc: "Prediksi HW Composer untuk respons sentuhan 0ms.", 
            on: "setprop debug.sf.predict_hwc_composition_strategy 1; setprop ro.input.video_mode 1; setprop debug.hwui.fps_divisor 1; setprop debug.cpurend.vsync false; service call SurfaceFlinger 1008 i32 1; setprop debug.sf.disable_backpressure 1; setprop debug.sf.latch_unsignaled 1; dumpsys SurfaceFlinger --latency-clear;", 
            off: "setprop debug.sf.predict_hwc_composition_strategy 0; setprop ro.input.video_mode 0; setprop debug.hwui.fps_divisor 0; setprop debug.cpurend.vsync true; service call SurfaceFlinger 1008 i32 0; setprop debug.sf.disable_backpressure 0; setprop debug.sf.latch_unsignaled 0;" 
        },
        { 
            name: "SurfaceFlinger X-Phase", 
            desc: "Latensi offset kustom untuk frame pipelining kompetitif.", 
            on: "setprop debug.sf.early_phase_offset_ns 500000; setprop debug.sf.early_app_phase_offset_ns 500000; setprop debug.sf.early_gl_phase_offset_ns 3000000; setprop debug.sf.high_fps_early_phase_offset_ns 6100000; setprop debug.sf.high_fps_late_app_phase_offset_ns 100000;", 
            off: "setprop debug.sf.early_phase_offset_ns ''; setprop debug.sf.early_app_phase_offset_ns ''; setprop debug.sf.early_gl_phase_offset_ns ''; setprop debug.sf.high_fps_early_phase_offset_ns ''; setprop debug.sf.high_fps_late_app_phase_offset_ns '';" 
        }
    ],
    "aim": [
        { 
            name: "Input Dispatcher Boost", 
            desc: "Prioritas input & MEMC request untuk latensi layar minimal.", 
            on: "settings put global input_boost_enabled 1; settings put global input_low_latency 1; settings put global latency_reduction 1; settings put global sf_touch_timer_ms 200; write /sys/module/cpu_input_boost/parameters/input_boost_duration 0; write /sys/module/cpu_input_boost/parameters/dynamic_stune_boost_duration 0;", 
            off: "settings delete global input_boost_enabled; settings delete global input_low_latency; settings delete global latency_reduction; settings delete global sf_touch_timer_ms;" 
        },
        { 
            name: "Kernel Stune Target", 
            desc: "Bypass schedtune limit top-app untuk CPU priority.", 
            on: "for dir in /dev/stune/top-app /dev/stune/foreground /dev/stune/rt; do echo '20' > $dir/schedtune.boost 2>/dev/null; echo '0' > $dir/schedtune.prefer_idle 2>/dev/null; done;", 
            off: "for dir in /dev/stune/top-app /dev/stune/foreground /dev/stune/rt; do echo '0' > $dir/schedtune.boost 2>/dev/null; echo '1' > $dir/schedtune.prefer_idle 2>/dev/null; done;" 
        },
        {
            name: "CPU Input Boost Tuning",
            desc: "Kunci hispeed_load agar CPU boost instan saat disentuh.",
            on: "echo 100 > /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_load 2>/dev/null; echo 100 > /sys/devices/system/cpu/cpufreq/policy4/schedutil/hispeed_load 2>/dev/null; echo 1 > /sys/module/msm_schedutil/parameters/touchboost 2>/dev/null;",
            off: "echo 90 > /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_load 2>/dev/null; echo 0 > /sys/module/msm_schedutil/parameters/touchboost 2>/dev/null;"
        }
    ],
    "gfx": [
        { 
            name: "Vulkan MSAA 4x Engine", 
            desc: "Grafis tajam dengan backend Skia Vulkan.", 
            on: "setprop debug.hwui.renderer skiavk; setprop debug.renderengine.backend skiavk; setprop debug.egl.force_msaa 2; setprop debug.sf.disable_antialiasing 1; setprop persist.sys.force_sw_gles 0; setprop debug.egl.hw 1; setprop debug.sf.hw 1;", 
            off: "setprop debug.hwui.renderer opengl; setprop debug.renderengine.backend opengl; setprop debug.egl.force_msaa 0; setprop debug.egl.hw 0; setprop debug.sf.hw 0;" 
        },
        { 
            name: "Enterprise HWUI Cache", 
            desc: "Ekspansi memori cache render untuk zero stuttering.", 
            on: "setprop ro.hwui.texture_cache_size 128; setprop ro.hwui.layer_cache_size 64; setprop ro.hwui.path_cache_size 64; setprop ro.hwui.r_buffer_cache_size 16; setprop ro.hwui.drop_shadow_cache_size 8; setprop ro.hwui.texture_cache_flushrate 0.2; setprop debug.hwui.disable_vsync true;", 
            off: "setprop ro.hwui.texture_cache_size 24; setprop ro.hwui.layer_cache_size 16; setprop debug.hwui.disable_vsync false;" 
        },
        {
            name: "SurfaceFlinger High-End",
            desc: "Force 16bpp alpha, triple buffering, vsync disabled.",
            on: "setprop persist.sys.use_16bpp_alpha 1; setprop persist.sys.use_dithering 0; setprop ro.surface_flinger.max_frame_buffer_acquired_buffers 3; setprop debug.sf.showupdates 0; setprop debug.gpurend.vsync false; setprop debug.hwui.use_buffer_age false; setprop ro.surface_flinger.protected_contents true;",
            off: "setprop persist.sys.use_16bpp_alpha 0; setprop persist.sys.use_dithering 1; setprop ro.surface_flinger.max_frame_buffer_acquired_buffers 2; setprop debug.gpurend.vsync true; setprop ro.surface_flinger.protected_contents false;"
        },
        {
            name: "Force HighEndGFX",
            desc: "Inject config system.prop untuk visual puncak.",
            on: "settings put system force_highendgfx true; settings put global media.enc.jpeg.quality 100; setprop ro.opengles.version 196608; setprop persist.sys.ui.hw true; setprop persist.sys.ui.statusbar.alpha 1;",
            off: "settings delete system force_highendgfx; settings delete global media.enc.jpeg.quality; setprop persist.sys.ui.hw false;"
        }
    ],
    "perf": [
        { 
            name: "Ultimate Performance Gov", 
            desc: "Kunci frekuensi, matikan Doze, gaming ekstrem.", 
            on: "cmd power set-fixed-performance-mode-enabled true; setprop debug.sys.performance_mode 1; setprop persist.sys.performance_mode true; setprop persist.sys.boost_performance true; setprop sys.perf.topAppBoost.enable true; dumpsys deviceidle disable; settings put global app_standby_enabled 0;", 
            off: "cmd power set-fixed-performance-mode-enabled false; setprop debug.sys.performance_mode 0; setprop persist.sys.performance_mode false; dumpsys deviceidle enable; settings delete global app_standby_enabled;" 
        },
        { 
            name: "Thermal Throttle Nullifier", 
            desc: "Bypass engine mitigasi suhu bawaan vendor.", 
            on: "cmd thermalservice override-status 0; setprop debug.thermal.throttle false; setprop debug.thermal.disable 1; setprop persist.sys.thermal.disable 1; setprop persist.vendor.thermal.engine false; settings put global persist.sys.smartpower.display_thermal_temp_threshold 99;", 
            off: "cmd thermalservice reset; setprop debug.thermal.throttle true; setprop debug.thermal.disable 0; setprop persist.vendor.thermal.engine true;" 
        },
        { 
            name: "Dalvik & System Unlocker", 
            desc: "Multithread, cegah OS mematikan game, matikan preload.", 
            on: "setprop persist.sys.dalvik.hyperthreading true; setprop persist.sys.dalvik.multithread true; setprop ro.zygote.preload.enable 0; cmd device_config put activity_manager max_cached_processes 256; cmd device_config put activity_manager max_phantom_processes 2147483647; settings put global settings_enable_monitor_phantom_procs false;", 
            off: "setprop persist.sys.dalvik.hyperthreading false; setprop persist.sys.dalvik.multithread false; setprop ro.zygote.preload.enable 1; cmd device_config delete activity_manager max_phantom_processes; cmd device_config delete activity_manager max_cached_processes;" 
        },
        { 
            name: "Disable GMS & Bloatware", 
            desc: "Matikan analitik Google, Joyose, GOS, Iorapd.", 
            on: "settings put secure assistant 0; settings put global google_core_control 0; settings put global hotword_detection_enabled 0; settings put global iorapd.enable false; settings put global config.htc.nocheckin 1; settings put global config.nocheckin 1; settings put global logcat.live disable; settings put global debugtool.anrhistory 0; pm disable com.xiaomi.joyose 2>/dev/null; pm disable com.samsung.android.game.gos 2>/dev/null;", 
            off: "settings delete secure assistant; settings delete global google_core_control; settings delete global iorapd.enable; settings delete global config.nocheckin; settings delete global logcat.live;" 
        }
    ],
    "clean": [
        { 
            name: "Deep VM & RAM Flush", 
            desc: "Pembersihan total memori level kernel. Mengatur Swappiness.", 
            on: "sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null; echo 1 > /proc/sys/vm/compact_memory 2>/dev/null; echo 10 > /proc/sys/vm/dirty_background_ratio 2>/dev/null; echo 100 > /proc/sys/vm/dirty_ratio 2>/dev/null; echo 6000 > /proc/sys/vm/dirty_expire_centisecs 2>/dev/null; echo 6000 > /proc/sys/vm/dirty_writeback_centisecs 2>/dev/null; echo 200 > /proc/sys/vm/swappiness 2>/dev/null; echo 200 > /proc/sys/vm/vfs_cache_pressure 2>/dev/null; am kill-all; dumpsys meminfo --clear-all-caches;", 
            off: "echo 1 > /proc/sys/vm/drop_caches 2>/dev/null;" 
        },
        { 
            name: "Storage FSTRIM & I/O Deadline", 
            desc: "Penyelarasan blok memori dan eksekusi scheduler deadline.", 
            on: "for block in /sys/block/*/queue; do echo 'deadline' > $block/scheduler 2>/dev/null; echo '1024' > $block/read_ahead_kb 2>/dev/null; echo '0' > $block/add_random 2>/dev/null; done; sm fstrim; vdc fstrim dotrim 2>/dev/null; fstrim -v /data 2>/dev/null; fstrim -v /system 2>/dev/null; [ \"$(blkid /dev/block/bootdevice/by-name/userdata | grep f2fs)\" ] && { echo 'tuning' > /sys/fs/f2fs/*/discard_unit 2>/dev/null; echo '1' > /sys/fs/f2fs/*/ipu_policy 2>/dev/null; };", 
            off: "for block in /sys/block/*/queue; do echo 'cfq' > $block/scheduler 2>/dev/null; done;" 
        },
        { 
            name: "Wipe Dalvik & GPU Cache", 
            desc: "Menghapus sampah kompilasi dan render shader lama.", 
            on: "pm trim-caches 999999999999999999; cmd package bg-dexopt-job; rm -rf /data/user_de/0/*/code_cache/* 2>/dev/null; rm -rf /data/user_de/0/*/cache/* 2>/dev/null;", 
            off: "echo 'Success'" 
        },
        { 
            name: "Clear Tombstones & Logs", 
            desc: "Wipe log ANR, tombstone, dan riwayat baterai.", 
            on: "rm -rf /data/tombstones/* 2>/dev/null; rm -rf /data/anr/* 2>/dev/null; rm -rf /data/system/usagestats/* 2>/dev/null; settings put global dropbox:dumpsys:procstats 0; logcat -c;", 
            off: "settings delete global dropbox:dumpsys:procstats;" 
        }
    ]
};

const fpsValues = [60, 90, 120, 144, 165, 240];
const dpiValues = [360, 392, 411, 440, 480, 520, 560, 600];
const slpValues = [0, 4, 8, 12, 16];

let currentDPIIndex = 2;
let currentFPSIndex = 0;
let isXModeActive = false;
let isPanelVisible = true;
let sysData = { ram: 0, cpu: 0, temp: 0 };

const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 1500,
    background: '#09090b',
    color: '#06b6d4',
    customClass: { popup: 'border border-cyan-800 rounded-lg font-mono-custom shadow-[0_0_15px_rgba(6,182,212,0.2)]' }
});

document.addEventListener('DOMContentLoaded', async () => {
    initMarkers();
    switchTab('vip', document.querySelector('.nav-pill'));
    fetchAnimeAvatar();
    startHardwareMonitor();
    await fetchCurrentSettings();
});

function showLoader(text) {
    const loader = document.getElementById('cyber-loader');
    document.getElementById('loader-text').innerText = text;
    loader.style.display = 'flex';
    loader.classList.remove('hidden');
    requestAnimationFrame(() => {
        loader.style.opacity = '1';
    });
}

function hideLoader() {
    const loader = document.getElementById('cyber-loader');
    loader.style.opacity = '0';
    setTimeout(() => { 
        loader.classList.add('hidden');
        loader.style.display = 'none';
    }, 300);
}

function initMarkers() {
    const createMarkers = (trackId, count) => {
        const track = document.getElementById(trackId);
        track.innerHTML = '';
        for(let i=0; i<count; i++) {
            let dot = document.createElement('div');
            dot.className = 'step-dot';
            track.appendChild(dot);
        }
    };
    createMarkers('track-fps', 6);
    createMarkers('track-dpi', 8);
    createMarkers('track-pointer', 7);
    createMarkers('track-slop', 5);
}

function updateMarkers(trackId, index) {
    const dots = document.getElementById(trackId).children;
    for(let i=0; i<dots.length; i++) {
        if(i <= index) dots[i].classList.add('active');
        else dots[i].classList.remove('active');
    }
}

function togglePanel() {
    const mainPanel = document.getElementById('main-panel');
    const floatBtn = document.getElementById('floating-btn');
    if (isPanelVisible) {
        mainPanel.classList.add('panel-hidden');
        setTimeout(() => {
            mainPanel.style.display = 'none';
            floatBtn.style.display = 'flex';
            setTimeout(() => floatBtn.classList.remove('hidden'), 50);
        }, 400);
    } else {
        floatBtn.classList.add('hidden');
        setTimeout(() => {
            floatBtn.style.display = 'none';
            mainPanel.style.display = 'flex';
            setTimeout(() => mainPanel.classList.remove('panel-hidden'), 50);
        }, 300);
    }
    isPanelVisible = !isPanelVisible;
}

async function fetchAnimeAvatar() {
    try {
        let res = await fetch('https://nekos.best/api/v2/neko');
        let data = await res.json();
        if (data.results && data.results[0] && data.results[0].url) {
            document.getElementById('anime-avatar').src = data.results[0].url;
        }
    } catch(e) {}
}

async function runShellSilent(cmd, showLoad = true, loadText = "INJECTING PAYLOAD...") {
    if(showLoad) showLoader(loadText);
    try {
        let res = await fetch('/execute?cmd=' + encodeURIComponent(cmd));
        let data = await res.json();
        if(showLoad) hideLoader();
        return data.output || "Success";
    } catch(e) { 
        if(showLoad) { hideLoader(); Toast.fire({ icon: 'error', title: 'ENGINE OFFLINE' }); }
        return "Error"; 
    }
}

function updateUI() {
    let elRam = document.getElementById('hw-ram');
    let elCpu = document.getElementById('hw-cpu');
    let elTemp = document.getElementById('hw-temp');
    if(elTemp) elTemp.innerText = sysData.temp + "°C";
    if(elRam) elRam.innerText = sysData.ram + "%";
    if(elCpu) elCpu.innerText = sysData.cpu + "%";
}

function startHardwareMonitor() {
    setInterval(async () => {
        let script = "echo S:$(cat /proc/stat | head -n 1); echo M:$(cat /proc/meminfo | grep MemTotal | grep -o '[0-9]*'); echo A:$(cat /proc/meminfo | grep MemAvailable | grep -o '[0-9]*'); echo T:$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null || dumpsys battery | grep temperature | grep -o '[0-9]*' | head -n 1)";
        let res = await runShellSilent(script, false);
        if (res !== "Error" && res !== "Unknown") {
            try {
                let cpuMatch = res.match(/S:cpu\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)/);
                let memTMatch = res.match(/M:(\d+)/);
                let memAMatch = res.match(/A:(\d+)/);
                let tempMatch = res.match(/T:(\d+)/);

                if (cpuMatch) {
                    let idle = parseInt(cpuMatch[4]);
                    let total = parseInt(cpuMatch[1]) + parseInt(cpuMatch[2]) + parseInt(cpuMatch[3]) + idle;
                    if (window.lastCpu) {
                        let diffTotal = total - window.lastCpu.total;
                        sysData.cpu = Math.round((1000 * (diffTotal - (idle - window.lastCpu.idle)) / diffTotal + 5) / 10);
                    }
                    window.lastCpu = { idle, total };
                }
                if (memTMatch && memAMatch) {
                    let totalRam = parseInt(memTMatch[1]);
                    let availRam = parseInt(memAMatch[1]);
                    sysData.ram = Math.round(((totalRam - availRam) / totalRam) * 100);
                }
                if (tempMatch) {
                    let t = parseInt(tempMatch[1]);
                    sysData.temp = t > 1000 ? (t / 1000).toFixed(1) : (t > 100 ? (t / 10).toFixed(1) : t);
                }
                requestAnimationFrame(updateUI);
            } catch(e) {}
        }
    }, 1500);
}

async function toggleFloating() {
    showLoader("SYNCING HUD...");
    try {
        let res = await fetch('/api/floating?action=check');
        let data = await res.json();
        if (data.status === 'denied') {
            hideLoader();
            Swal.fire({
                title: 'PERMISSION REQUIRED',
                text: 'Display Over Other Apps permission is missing.',
                background: '#09090b', color: '#e4e4e7', confirmButtonColor: '#06b6d4', confirmButtonText: 'GRANT',
                customClass: { popup: 'border border-cyan-500 rounded-lg font-mono-custom shadow-[0_0_15px_rgba(6,182,212,0.3)]' }
            }).then(async (result) => {
                if (result.isConfirmed) await fetch('/api/floating?action=request');
            });
        } else {
            let toggleRes = await fetch('/api/floating?action=toggle');
            let toggleData = await toggleRes.json();
            hideLoader();
            let msg = toggleData.status === 'started' ? 'HUD OVERLAY ON' : 'HUD OVERLAY OFF';
            Toast.fire({ icon: 'success', title: msg });
        }
    } catch(e) {
        hideLoader();
        Toast.fire({ icon: 'error', title: 'API ERROR' });
    }
}

async function toggleXMode() {
    isXModeActive = !isXModeActive;
    let btn = document.getElementById('btn-xmode');
    let cmdOn = "cmd power set-fixed-performance-mode-enabled true; cmd thermalservice override-status 1; settings put system peak_refresh_rate 999; settings put global min_fps 120; setprop persist.sys.performance_mode true; setprop sys.perf.topAppBoost.enable true;";
    let cmdOff = "cmd power set-fixed-performance-mode-enabled false; cmd thermalservice reset; settings delete system peak_refresh_rate; setprop persist.sys.performance_mode false;";
    
    if (isXModeActive) {
        btn.classList.add('xmode-active');
        await runShellSilent(cmdOn, true, "ENGAGING X-MODE...");
        Toast.fire({ icon: 'success', title: 'OVERCLOCK ENGAGED' });
    } else {
        btn.classList.remove('xmode-active');
        await runShellSilent(cmdOff, true, "DISENGAGING X-MODE...");
        Toast.fire({ icon: 'info', title: 'SYSTEM SECURED' });
    }
}

async function executeAction(type) {
    let cmd = "";
    if (type === 'ram') {
        cmd = "sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null; echo 1 > /proc/sys/vm/compact_memory 2>/dev/null; am kill-all; dumpsys meminfo --clear-all-caches;";
        await runShellSilent(cmd, true, "FLUSHING MEMORY...");
        Toast.fire({ icon: 'success', title: 'DEEP FLUSH SUCCESS' });
    } else if (type === 'network') {
        cmd = "ndc resolver flushdefaultif; ndc resolver flushnet eth0; ndc resolver flushnet wlan0; settings put global tcp_congestion_control bbr; setprop net.tcp.buffersize.default 4096,87380,256960,4096,16384,256960; setprop net.ipv4.tcp_fastopen 3;";
        await runShellSilent(cmd, true, "ROUTING NETWORK...");
        Toast.fire({ icon: 'success', title: 'NETWORK OPTIMIZED' });
    }
}

async function handleToggleAction(isChecked, tabId, idx) {
    let tweak = DB[tabId][idx];
    let cmd = isChecked ? tweak.on : tweak.off;
    await runShellSilent(cmd, true, "INJECTING KERNEL...");
    Toast.fire({ icon: 'success', title: 'APPLIED', text: tweak.name });
}

function updateDisplay(id, val, type) { 
    if(type === 'pointer') {
        document.getElementById(id).innerText = val;
        updateMarkers('track-pointer', parseInt(val)-1);
    } else if(type === 'slop') {
        document.getElementById(id).innerText = slpValues[val];
        updateMarkers('track-slop', val);
    }
}
function updateDpiDisplay(sliderIndex) { 
    document.getElementById('val-dpi').innerText = dpiValues[sliderIndex]; 
    updateMarkers('track-dpi', sliderIndex);
}
function updateFpsDisplay(sliderIndex) { 
    document.getElementById('val-fps').innerText = fpsValues[sliderIndex] + "Hz";
    updateMarkers('track-fps', sliderIndex);
}

async function fetchCurrentSettings() {
    try {
        let resDpi = await runShellSilent("wm density", false);
        if(resDpi && resDpi !== "Error") {
            let dpiMatch = resDpi.match(/Override density: (\d+)/) || resDpi.match(/Physical density: (\d+)/);
            if(dpiMatch) {
                let actualDPI = parseInt(dpiMatch[1]);
                let closestIndex = dpiValues.reduce((prev, curr, idx) => Math.abs(curr - actualDPI) < Math.abs(dpiValues[prev] - actualDPI) ? idx : prev, 0);
                document.getElementById('slider-dpi').value = closestIndex;
                updateDpiDisplay(closestIndex);
            }
        }
        
        let resFps = await runShellSilent("settings get system peak_refresh_rate", false);
        if(resFps && !isNaN(parseInt(resFps))) {
            let val = parseInt(resFps);
            let closest = fpsValues.reduce((prev, curr, idx) => Math.abs(curr - val) < Math.abs(fpsValues[prev] - val) ? idx : prev, 0);
            document.getElementById('slider-fps').value = closest;
            updateFpsDisplay(closest);
        }
        
        let resPtr = await runShellSilent("settings get system pointer_speed", false);
        if(resPtr && !isNaN(parseInt(resPtr))) {
            let pVal = parseInt(resPtr);
            document.getElementById('slider-pointer').value = pVal;
            updateDisplay('val-pointer', pVal, 'pointer');
        }
    } catch(e) {}
}

async function applyDpiSlider(sliderIndex) {
    let exactDpi = dpiValues[sliderIndex];
    await runShellSilent(`wm density ${exactDpi};`, true, "APPLYING DENSITY...");
}

async function applyFpsSlider(sliderIndex) {
    let val = fpsValues[sliderIndex];
    let cmd = `cmd display set-match-content-frame-rate-pref 2; settings put system peak_refresh_rate ${val}; settings put system min_refresh_rate ${val}; settings put system user_refresh_rate ${val}; settings put global thermal_limit_refresh_rate ${val}; setprop persist.sys.min_fps ${val}; setprop persist.sys.max_fps ${val}; setprop persist.sys.NV_FPSLIMIT ${val}; setprop ro.vendor.display.max_fps ${val}; cmd device_config put system display_refresh_rate ${val};`;
    await runShellSilent(cmd, true, "LOCKING REFRESH RATE...");
}

async function applySlider(type, val) {
    let cmd = "";
    if(type === 'pointer') { cmd = `settings put system pointer_speed ${val};`; }
    else if(type === 'slop') { let exactSlop = slpValues[val]; cmd = `settings put global touch_slop ${exactSlop};`; }
    await runShellSilent(cmd, true, "CALIBRATING TOUCH...");
}

async function injectAllSliders() {
    let dpiVal = dpiValues[document.getElementById('slider-dpi').value];
    let fpsVal = fpsValues[document.getElementById('slider-fps').value];
    let ptr = document.getElementById('slider-pointer').value;
    let slpVal = slpValues[document.getElementById('slider-slop').value];
    
    let cmd = `wm density ${dpiVal}; cmd display set-match-content-frame-rate-pref 2; settings put system peak_refresh_rate ${fpsVal}; settings put system min_refresh_rate ${fpsVal}; settings put system user_refresh_rate ${fpsVal}; settings put global thermal_limit_refresh_rate ${fpsVal}; setprop persist.sys.min_fps ${fpsVal}; setprop persist.sys.max_fps ${fpsVal}; setprop persist.sys.NV_FPSLIMIT ${fpsVal}; setprop ro.vendor.display.max_fps ${fpsVal}; cmd device_config put system display_refresh_rate ${fpsVal}; settings put system pointer_speed ${ptr}; settings put global touch_slop ${slpVal};`;
    
    await runShellSilent(cmd, true, "FORCING ALL CALIBRATIONS...");
    Toast.fire({ icon: 'success', title: 'PARAMETERS SYNCED' });
}

async function restoreDefaults() {
    let masterReset = `
    wm density reset;
    settings delete system pointer_speed;
    settings delete global touch_slop;
    settings delete system peak_refresh_rate;
    settings delete system min_refresh_rate;
    settings delete system user_refresh_rate;
    settings delete global thermal_limit_refresh_rate;
    cmd display set-match-content-frame-rate-pref 0;
    setprop debug.graphics.game_default_frame_rate.disabled 0;
    settings delete system game_scene_more_fps;
    settings delete system gamewatch_game_target_fps;
    settings delete global game_memc_request_touch_rate;
    setprop ro.input.scroll_friction 0.015;
    setprop view.scroll_friction 0.015;
    settings delete system touch.pressure.scale;
    settings delete system touch.size.scale;
    setprop windowsmgr.max_events_per_sec 90;
    settings delete global tap_duration_threshold;
    setprop debug.sf.predict_hwc_composition_strategy 0;
    setprop ro.input.video_mode 0;
    setprop debug.hwui.fps_divisor 0;
    setprop debug.cpurend.vsync true;
    service call SurfaceFlinger 1008 i32 0;
    setprop debug.sf.disable_backpressure 0;
    setprop debug.sf.latch_unsignaled 0;
    settings delete global input_boost_enabled;
    settings delete global input_low_latency;
    settings delete global latency_reduction;
    settings delete global sf_touch_timer_ms;
    setprop debug.hwui.renderer opengl;
    setprop debug.renderengine.backend opengl;
    setprop debug.egl.force_msaa 0;
    setprop debug.sf.disable_antialiasing 0;
    setprop debug.egl.hw 0;
    setprop debug.sf.hw 0;
    cmd power set-fixed-performance-mode-enabled false;
    setprop debug.sys.performance_mode 0;
    setprop persist.sys.performance_mode false;
    dumpsys deviceidle enable;
    settings delete global app_standby_enabled;
    cmd thermalservice reset;
    setprop debug.thermal.throttle true;
    setprop debug.thermal.disable 0;
    setprop persist.sys.thermal.disable 0;
    setprop persist.vendor.thermal.engine true;
    setprop persist.sys.dalvik.hyperthreading false;
    setprop persist.sys.dalvik.multithread false;
    setprop dalvik.vm.usap_pool_enabled false;
    cmd device_config delete activity_manager max_phantom_processes;
    cmd device_config delete activity_manager max_cached_processes;
    settings delete secure assistant;
    settings delete global google_core_control;
    settings delete global hotword_detection_enabled;
    `;
    
    await runShellSilent(masterReset, true, "RESTORING DEFAULTS...");
    document.querySelectorAll('.cyber-toggle input').forEach(cb => cb.checked = false);
    
    if(isXModeActive) {
        isXModeActive = false;
        document.getElementById('btn-xmode').classList.remove('xmode-active');
    }
    
    await fetchCurrentSettings();
    let ptrSlider = document.getElementById('slider-pointer');
    let slpSlider = document.getElementById('slider-slop');
    if(ptrSlider) { ptrSlider.value = 4; updateDisplay('val-pointer', 4, 'pointer'); }
    if(slpSlider) { slpSlider.value = 2; updateDisplay('val-slop', 2, 'slop'); }
    Toast.fire({ icon: 'info', title: 'SYSTEM RESET' });
}

function switchTab(tabId, btnElement) {
    document.querySelectorAll('.nav-pill').forEach(b => b.classList.remove('active'));
    btnElement.classList.add('active');
    const container = document.getElementById('tweaks-container');
    container.innerHTML = '';
    if (DB[tabId]) {
        DB[tabId].forEach((tweak, idx) => {
            const div = document.createElement('div');
            div.className = 'glass-panel p-2.5 md:p-3.5 flex items-center justify-between shrink-0 hover:border-cyan-500/30 transition-colors group';
            div.innerHTML = `
                <div class="pr-2 flex-1 min-w-0">
                    <span class="text-[9px] md:text-[11px] font-bold text-zinc-200 block tracking-wide group-hover:text-cyan-400 transition-colors truncate">${tweak.name}</span>
                    <span class="text-[7px] md:text-[9px] text-zinc-500 font-medium leading-snug mt-0.5 block line-clamp-2">${tweak.desc}</span>
                </div>
                <label class="relative inline-flex items-center cursor-pointer shrink-0 cyber-toggle">
                    <input type="checkbox" class="sr-only" onchange="handleToggleAction(this.checked, '${tabId}', ${idx})">
                    <div class="w-8 h-4 md:w-10 md:h-5 bg-black border border-zinc-700 rounded-full transition-all duration-300">
                        <div class="w-3 h-3 md:w-4 md:h-4 bg-zinc-500 rounded-full transform translate-x-[2px] translate-y-[1px] transition-all duration-300"></div>
                    </div>
                </label>
            `;
            container.appendChild(div);
        });
    }
}
