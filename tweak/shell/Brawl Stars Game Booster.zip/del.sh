#!/system/bin/sh
MOD_NAME="Brawl Stars Game Booster"
LOG_DIR="/sdcard/AgungShellLogs"
LOG_FILE="$LOG_DIR/$(echo "$MOD_NAME" | tr ' /' '__')_reset_$(date +%Y%m%d_%H%M%S).log"
mkdir -p "$LOG_DIR" 2>/dev/null
pg(){ settings put global "$1" "$2" >>"$LOG_FILE" 2>&1; }
ps(){ settings put system "$1" "$2" >>"$LOG_FILE" 2>&1; }
pc(){ settings put secure "$1" "$2" >>"$LOG_FILE" 2>&1; }
dg(){ settings delete global "$1" >>"$LOG_FILE" 2>&1; }
ds(){ settings delete system "$1" >>"$LOG_FILE" 2>&1; }
notify(){ cmd notification post -S bigtext -t "$1" "agung_reset_$(date +%s)" "$2" >>"$LOG_FILE" 2>&1; }
pg window_animation_scale 1
pg transition_animation_scale 1
pg animator_duration_scale 1
pg background_process_limit 0
dg cached_apps_freezer
dg app_standby_enabled
dg adaptive_battery_management_enabled
dg force_gpu_rendering
pc long_press_timeout 500
pc multi_press_timeout 300
ps pointer_speed 0
ps haptic_feedback_enabled 1
ps sound_effects_enabled 1
ps lockscreen_sounds_enabled 1
ds min_refresh_rate
ds peak_refresh_rate
cmd package trim-caches 999G >>"$LOG_FILE" 2>&1
sync
notify "$MOD_NAME Berhasil Di Reset, Module By Agung Developer." "Reset selesai. Log: $LOG_FILE"
