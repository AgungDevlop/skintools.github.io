PUBG Mobile Game Booster
Support: Non Root + Root
Files:
- execute.sh
- agresif.sh
- del.sh

Fixed shell syntax version.
