#!/system/bin/sh

MOD_NAME="Bus Simulator Indonesia Game Booster"
MODE_NAME="agresif"
HAS_ADS="1"

LOG_DIR="/sdcard/AgungShellLogs"
SAFE_DIR="/sdcard/AgungShellSafe"
LOG_FILE="$LOG_DIR/$(echo "$MOD_NAME" | tr ' /' '__')_${MODE_NAME}_$(date +%Y%m%d_%H%M%S).log"

mkdir -p "$LOG_DIR" "$SAFE_DIR" 2>/dev/null

log_msg() {
    echo "[$(date '+%H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

has_cmd() {
    command -v "$1" >/dev/null 2>&1
}

is_root() {
    if [ "$(id -u 2>/dev/null)" = "0" ]; then
        return 0
    fi

    if has_cmd su; then
        su -c "id" 2>/dev/null | grep -q "uid=0" && return 0
    fi

    return 1
}

run_root() {
    if [ "$(id -u 2>/dev/null)" = "0" ]; then
        sh -c "$1" >> "$LOG_FILE" 2>&1
    elif has_cmd su; then
        su -c "$1" >> "$LOG_FILE" 2>&1
    fi
}

put_global() {
    settings put global "$1" "$2" >> "$LOG_FILE" 2>&1
}

put_system() {
    settings put system "$1" "$2" >> "$LOG_FILE" 2>&1
}

put_secure() {
    settings put secure "$1" "$2" >> "$LOG_FILE" 2>&1
}

notify_user() {
    TITLE="$1"
    BODY="$2"

    cmd notification post -S bigtext -t "$TITLE" "agung_${MODE_NAME}_$(date +%s)" "$BODY" >> "$LOG_FILE" 2>&1 && return 0
    cmd notification post -t "$TITLE" "agung_${MODE_NAME}_$(date +%s)" "$BODY" >> "$LOG_FILE" 2>&1 && return 0
    return 0
}

open_random_ad() {
    if [ "$HAS_ADS" != "1" ]; then
        return 0
    fi

    NOW="$(date +%s)"
    PICK=$((NOW % 4))

    case "$PICK" in
        0) URL="https://omg10.com/4/10055984" ;;
        1) URL="https://sorrowfulpsychology.com/HE9TFh" ;;
        2) URL="https://dulyhagglermounting.com/2082665" ;;
        *) URL="https://jb.xylenolshivahs.com/iLMNRjfsHJiW4/94691" ;;
    esac

    monkey -p com.android.chrome -c android.intent.category.LAUNCHER 1 >> "$LOG_FILE" 2>&1
    sleep 1
    am start -a android.intent.action.VIEW -d "$URL" com.android.chrome >> "$LOG_FILE" 2>&1 || am start -a android.intent.action.VIEW -d "$URL" >> "$LOG_FILE" 2>&1
}

cache_clean() {
    cmd package trim-caches 999G >> "$LOG_FILE" 2>&1
    pm trim-caches 999G >> "$LOG_FILE" 2>&1
    logcat -c >> "$LOG_FILE" 2>&1
}

dexopt_safe() {
    cmd package compile -m speed-profile -a >> "$LOG_FILE" 2>&1
    cmd package bg-dexopt-job >> "$LOG_FILE" 2>&1
    cmd jobscheduler run -f android 800 >> "$LOG_FILE" 2>&1
}

kill_background_safe() {
    if [ "1" = "1" ]; then
        am kill-all >> "$LOG_FILE" 2>&1
        cmd activity kill-all >> "$LOG_FILE" 2>&1
    fi
}

root_tune_safe() {
    run_root "echo 20 > /proc/sys/vm/swappiness 2>/dev/null"
    run_root "echo 80 > /proc/sys/vm/vfs_cache_pressure 2>/dev/null"
    run_root "echo 15 > /proc/sys/vm/dirty_ratio 2>/dev/null"
    run_root "echo 5 > /proc/sys/vm/dirty_background_ratio 2>/dev/null"
    run_root "echo 2500 > /proc/sys/vm/dirty_expire_centisecs 2>/dev/null"
    run_root "echo 500 > /proc/sys/vm/dirty_writeback_centisecs 2>/dev/null"

    for READ_AHEAD in /sys/block/*/queue/read_ahead_kb; do
        run_root "[ -f '$READ_AHEAD' ] && echo 512 > '$READ_AHEAD' 2>/dev/null"
    done

    for GOV in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        run_root "[ -f '$GOV' ] && echo performance > '$GOV' 2>/dev/null"
    done

    
}

apply_non_root_settings() {
    put_global window_animation_scale "0"
    put_global transition_animation_scale "0"
    put_global animator_duration_scale "0"
    put_global background_process_limit "1"
    put_global cached_apps_freezer enabled
    put_global app_standby_enabled 1
    put_global adaptive_battery_management_enabled 1
    put_global enable_gpu_debug_layers 0
    put_global show_hw_screen_updates 0
    put_global show_hw_layers_updates 0
    put_global debug_view_attributes 0
    put_global force_gpu_rendering 0

    put_secure long_press_timeout 250
    put_secure multi_press_timeout 180

    put_system pointer_speed "7"
    put_system haptic_feedback_enabled 0
    put_system sound_effects_enabled 0
    put_system lockscreen_sounds_enabled 0
    put_system min_refresh_rate "120"
    put_system peak_refresh_rate "120"

    
}

main() {
    notify_user "$MOD_NAME Diproses" "Module By Agung Developer. Mode $MODE_NAME sedang dijalankan."

    log_msg "Module: $MOD_NAME"
    log_msg "Mode: $MODE_NAME"
    log_msg "Root: $(if is_root; then echo yes; else echo no; fi)"
    log_msg "Device: $(getprop ro.product.brand 2>/dev/null) $(getprop ro.product.model 2>/dev/null)"
    log_msg "Android: $(getprop ro.build.version.release 2>/dev/null)"

    apply_non_root_settings
    cache_clean
    kill_background_safe
    dexopt_safe

    if is_root; then
        root_tune_safe
    fi

    sync

    notify_user "$MOD_NAME Sukses Di Aktifkan, Module By Agung Developer." "Mode $MODE_NAME selesai. Support Root dan Non Root. Log: $LOG_FILE"
    open_random_ad

    log_msg "Selesai"
}

main
