Live Streaming Helper
Support: Non Root + Root
execute.sh normal
agresif.sh agresif
del.sh reset
