#!/system/bin/sh

MOD_NAME="Honor of Kings Game Booster"
LOG_DIR="/sdcard/AgungShellLogs"
LOG_FILE="$LOG_DIR/$(echo "$MOD_NAME" | tr ' /' '__')_reset_$(date +%Y%m%d_%H%M%S).log"

mkdir -p "$LOG_DIR" 2>/dev/null

put_global() {
    settings put global "$1" "$2" >> "$LOG_FILE" 2>&1
}

put_system() {
    settings put system "$1" "$2" >> "$LOG_FILE" 2>&1
}

put_secure() {
    settings put secure "$1" "$2" >> "$LOG_FILE" 2>&1
}

del_global() {
    settings delete global "$1" >> "$LOG_FILE" 2>&1
}

del_system() {
    settings delete system "$1" >> "$LOG_FILE" 2>&1
}

notify_user() {
    cmd notification post -S bigtext -t "$1" "agung_reset_$(date +%s)" "$2" >> "$LOG_FILE" 2>&1
}

put_global window_animation_scale 1
put_global transition_animation_scale 1
put_global animator_duration_scale 1
put_global background_process_limit 0

del_global cached_apps_freezer
del_global app_standby_enabled
del_global adaptive_battery_management_enabled
del_global enable_gpu_debug_layers
del_global show_hw_screen_updates
del_global show_hw_layers_updates
del_global debug_view_attributes
del_global force_gpu_rendering

put_secure long_press_timeout 500
put_secure multi_press_timeout 300

put_system pointer_speed 0
put_system haptic_feedback_enabled 1
put_system sound_effects_enabled 1
put_system lockscreen_sounds_enabled 1

del_system min_refresh_rate
del_system peak_refresh_rate

cmd package trim-caches 999G >> "$LOG_FILE" 2>&1
pm trim-caches 999G >> "$LOG_FILE" 2>&1
sync

notify_user "$MOD_NAME Berhasil Di Reset, Module By Agung Developer." "Reset selesai. Log: $LOG_FILE"
