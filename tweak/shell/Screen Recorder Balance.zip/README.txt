Screen Recorder Balance
Notification cleaned.
Tidak ada notifikasi iklan dibuka.
Notifikasi normal: Diproses, Sukses, Reset.
