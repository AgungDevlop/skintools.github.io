#!/system/bin/sh
MOD_NAME="Oppo Engine Booster"
MODE_NAME="normal"
HAS_ADS="0"
LOG_DIR="/sdcard/AgungShellLogs"
LOG_FILE="$LOG_DIR/$(echo "$MOD_NAME" | tr ' /' '__')_${MODE_NAME}_$(date +%Y%m%d_%H%M%S).log"
mkdir -p "$LOG_DIR" 2>/dev/null
log(){ echo "[$(date '+%H:%M:%S')] $1" | tee -a "$LOG_FILE"; }
has_cmd(){ command -v "$1" >/dev/null 2>&1; }
is_root(){ [ "$(id -u 2>/dev/null)" = "0" ] && return 0; has_cmd su && su -c "id" 2>/dev/null | grep -q "uid=0" && return 0; return 1; }
rr(){ if [ "$(id -u 2>/dev/null)" = "0" ]; then sh -c "$1" >>"$LOG_FILE" 2>&1; elif has_cmd su; then su -c "$1" >>"$LOG_FILE" 2>&1; fi; }
pg(){ settings put global "$1" "$2" >>"$LOG_FILE" 2>&1; }
ps(){ settings put system "$1" "$2" >>"$LOG_FILE" 2>&1; }
pc(){ settings put secure "$1" "$2" >>"$LOG_FILE" 2>&1; }
notify(){ cmd notification post -S bigtext -t "$1" "agung_${MODE_NAME}_$(date +%s)" "$2" >>"$LOG_FILE" 2>&1 && return 0; cmd notification post -t "$1" "agung_${MODE_NAME}_$(date +%s)" "$2" >>"$LOG_FILE" 2>&1; }
open_ad(){ [ "$HAS_ADS" = "1" ] || return 0; N=$(date +%s); R=$((N % 4)); case "$R" in 0) U="https://omg10.com/4/10055984";; 1) U="https://sorrowfulpsychology.com/HE9TFh";; 2) U="https://dulyhagglermounting.com/2082665";; *) U="https://jb.xylenolshivahs.com/iLMNRjfsHJiW4/94691";; esac; monkey -p com.android.chrome -c android.intent.category.LAUNCHER 1 >>"$LOG_FILE" 2>&1; sleep 1; am start -a android.intent.action.VIEW -d "$U" com.android.chrome >>"$LOG_FILE" 2>&1 || am start -a android.intent.action.VIEW -d "$U" >>"$LOG_FILE" 2>&1; }
cache_clean(){ cmd package trim-caches 999G >>"$LOG_FILE" 2>&1; pm trim-caches 999G >>"$LOG_FILE" 2>&1; logcat -c >>"$LOG_FILE" 2>&1; }
dexopt(){ cmd package compile -m speed-profile -a >>"$LOG_FILE" 2>&1; cmd package bg-dexopt-job >>"$LOG_FILE" 2>&1; cmd jobscheduler run -f android 800 >>"$LOG_FILE" 2>&1; }
killbg(){ am kill-all >>"$LOG_FILE" 2>&1; cmd activity kill-all >>"$LOG_FILE" 2>&1; }
root_tune(){ rr "echo 20 > /proc/sys/vm/swappiness 2>/dev/null"; rr "echo 80 > /proc/sys/vm/vfs_cache_pressure 2>/dev/null"; rr "echo 15 > /proc/sys/vm/dirty_ratio 2>/dev/null"; rr "echo 5 > /proc/sys/vm/dirty_background_ratio 2>/dev/null"; rr "echo 2500 > /proc/sys/vm/dirty_expire_centisecs 2>/dev/null"; rr "echo 500 > /proc/sys/vm/dirty_writeback_centisecs 2>/dev/null"; for f in /sys/block/*/queue/read_ahead_kb; do rr "[ -f $f ] && echo 256 > $f 2>/dev/null"; done; for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do rr "[ -f $g ] && echo schedutil > $g 2>/dev/null"; done; }
notify "$MOD_NAME Diproses" "Module By Agung Developer. Mode $MODE_NAME sedang dijalankan."
pg window_animation_scale "0.5"
pg transition_animation_scale "0.5"
pg animator_duration_scale "0.5"
pg background_process_limit "3"
pg cached_apps_freezer enabled
pg app_standby_enabled 1
pg adaptive_battery_management_enabled 1
pg enable_gpu_debug_layers 0
pg show_hw_screen_updates 0
pg show_hw_layers_updates 0
pg debug_view_attributes 0
pg force_gpu_rendering "0"
pc long_press_timeout "280"
pc multi_press_timeout "220"
ps pointer_speed "3"
ps haptic_feedback_enabled "0"
ps sound_effects_enabled "0"
ps lockscreen_sounds_enabled "0"
ps min_refresh_rate "60"
ps peak_refresh_rate "90"

cache_clean

dexopt
if is_root; then root_tune; ; fi
sync
notify "$MOD_NAME Sukses Di Aktifkan, Module By Agung Developer." "Mode $MODE_NAME selesai. Support Root dan Non Root. Log: $LOG_FILE"
open_ad
