#!/bin/bash

# Ram Booster - Universal Adaptive RAM Tweaks by Agung Developer

# Save installation date
date '+%Y-%m-%d %H:%M:%S' > /data/local/tmp/ram_booster_install_date

INSTALL_DATE=$(cat /data/local/tmp/ram_booster_install_date 2>/dev/null || echo "Unknown")

echo "---------------------------------------------"
echo "|         DEVICE AND HARDWARE INFO          |"
echo "---------------------------------------------"
echo "| Device   : $(getprop ro.product.manufacturer) $(getprop ro.product.model) |"
echo "| CPU      : $(getprop ro.board.platform) |"
echo "| GPU      : $(getprop ro.hardware) |"
echo "| Android  : $(getprop ro.build.version.release) |"
echo "| Install  : $INSTALL_DATE |"
echo "| Kernel   : $(uname -r) |"
echo "| Build    : $(getprop ro.build.display.id) |"
echo "| Root     : $(if [ $(id -u) -eq 0 ]; then echo 'Yes'; else echo 'No'; fi) |"
echo "| SELinux  : $(getenforce) |"
echo "---------------------------------------------"

echo ""
echo "=== WELCOME TO RAM BOOSTER INSTALLATION ==="
echo ""
sleep 1

# INSTALLATION PROCESS
echo "Starting RAM optimization..."
sleep 1
echo "Closing background apps..."
sleep 1
echo "Optimizing system settings..."
sleep 1
echo ""
(
settings put global animator_duration_scale 0
settings put global transition_animation_scale 0
settings put global window_animation_scale 0
settings put global activity_manager_constants max_cached_processes 8
settings put global settings_enable_monitor_phantom_procs false
settings put global bg_dexopt everything
settings put global config.spcm_enable false
settings put global config.spcm_kill_skip true
settings put global config.samp_spcm_enable false
settings put global config.spcm_db_enable false
settings put global config.spcm_db_launcher false
settings put global config.spcm_preload_enable false
settings put global config.spcm_gcm_kill_enable false
settings put global config.dha_cached_max 16
settings put global config.dha_empty_max 42
settings put global config.dha_empty_init 32
settings put global config.dha_lmk_scale 0.545
settings put global config.dha_th_rate 2.3
settings put global config.sdha_apps_bg_max 64
settings put global config.sdha_apps_bg_min 8
settings put global transition_animation_scale 0.5
settings put global window_animation_scale 0.5
settings put global animator_duration_scale 0.5
am kill-all
settings put global limit_background_processes 2
settings put system vm_drop_caches 1
stop tombstoned
am kill tombstoned
killall -9 tombstoned
settings put system force_all_apps_stopped 1
cmd activity force-stop "$app"
pm disable com.android.shell.tombstoned
settings put system air_motion_engine 0
settings put system air_motion_wake_up 0
settings put global activity_starts_logging_enabled 0
settings put global ble_scan_always_enabled 0
settings put global hotword_detection_enabled 0
settings put global mobile_data_always_on 0
settings put global network_recommendations_enabled 0
settings put global wifi_scan_always_enabled 0
settings put secure adaptive_sleep 0
settings put secure screensaver_activate_on_dock 0
settings put secure screensaver_activate_on_sleep 0
settings put secure screensaver_enabled 0
settings put secure send_action_app_error 0
settings put system intelligent_sleep_mode 0
settings put system master_motion 0
settings put system motion_engine 0
settings put system nearby_scanning_enabled 0
settings put system nearby_scanning_permission_allowed 0
settings put system rakuten_denwa 0
settings put system send_security_reports 0
) > /dev/null 2>&1 &

(
if [[ ! $(cmd -l | grep activity) ]]; then
echo "Not Supported"
exit
fi
) > /dev/null 2>&1 &

sleep 2
(
for app in $(cmd package list packages -3 | cut -f 2 -d ":"); do
if [[ ! "$app" == "me.piebridge.brevent" ]] && \
   [[ ! "$app" == "eu.sisik.hackendebug" ]] && \
   [[ ! "$app" == "com.whatsapp" ]] && \
   [[ ! "$app" == "com.omarea.vtools" ]] && \
   [[ ! "$app" == "com.miHoYo.GenshinImpact" ]] && \
   [[ ! "$app" == "com.dts.freefiremax" ]] && \
   [[ ! "$app" == "com.dts.freefireth" ]] && \
   [[ ! "$app" == "com.tencent.ig" ]] && \
   [[ ! "$app" == "com.mobile.legends" ]]; then
   echo "Force stopping $app"
   cmd activity force-stop "$app"
   sleep 1
   echo ""
fi
done
) > /dev/null 2>&1 &

for pkg in $(pm list packages -3 | grep -v brevent | cut -f 2 -d :); do
am force-stop --user 0 $pkg
am kill --user 0 $pkg
done
TMP_SCRIPT="/data/local/tmp/ram_booster"
rm -f "$TMP_SCRIPT"
sh "$TMP_SCRIPT" > /dev/null 2>&1 &

(
# Ram Booster - Universal Adaptive RAM Tweaks by Agung Developer
# Calculate adaptive settings based on total RAM
TOTAL_RAM=$(free -m | awk '/Mem:/ {print $2}')
MAX_CACHED=$((TOTAL_RAM / 256))
MAX_PHANTOM=$((MAX_CACHED / 2))
BG_LOW_MEM_MULT=$((TOTAL_RAM <= 4096 ? 3 : TOTAL_RAM <= 8192 ? 2 : 1))
CUR_MAX_CACHED=$((MAX_CACHED / 2))
SWAP_FREE_LOW=$((TOTAL_RAM <= 4096 ? 15 : TOTAL_RAM <= 8192 ? 10 : 5))
ZRAM_SIZE=$((TOTAL_RAM <= 4096 ? 3072 : TOTAL_RAM <= 8192 ? 2048 : 1024))
# Set global parameters
settings put global activity_manager_constants "max_cached_processes=${MAX_CACHED},max_phantom_processes=${MAX_PHANTOM},bg_low_mem_mult=${BG_LOW_MEM_MULT},cur_max_cached_processes=${CUR_MAX_CACHED}"
settings put global low_ram $( [ "$TOTAL_RAM" -le 4096 ] && echo true || echo false )
settings put global force_low_ram_device $( [ "$TOTAL_RAM" -le 4096 ] && echo true || echo false )
settings put system sys.haptic.low_ram $( [ "$TOTAL_RAM" -le 4096 ] && echo true || echo false )
settings put global swap_free_low_percentage ${SWAP_FREE_LOW}
settings put global zram_enable true
settings put global zram_size ${ZRAM_SIZE}
) > /dev/null 2>&1 &

# Clear All Frozen Apps (Reduce Active RAM)
(
am force-stop com.android.camera
am force-stop com.android.companiondevicemanager.auto_generated_characteristics_rro
am force-stop com.google.android.providers.media.module
am force-stop com.android.updater
am force-stop com.miui.powerkeeper
am force-stop com.qti.phone
am force-stop com.google.android.overlay.modules.permissioncontroller.forframework
am force-stop com.qualcomm.qti.server.wigig.tethering.rro
am force-stop android.miui.overlay
am force-stop com.qualcomm.qti.lpa
am force-stop android.miui.home.launcher.res
am force-stop com.qualcomm.atfwd
am force-stop com.qualcomm.qti.cne
am force-stop com.android.systemui.accessibility.accessibilitymenu
am force-stop com.android.dreams.phototable
am force-stop com.google.android.overlay.gmsconfig.comms
am force-stop com.android.overlay.gmscontactprovider
am force-stop com.miui.securitycore
am force-stop com.android.providers.contacts
am force-stop com.qualcomm.uimremoteserver
am force-stop com.android.dreams.basic
am force-stop com.android.companiondevicemanager
am force-stop com.android.cts.priv.ctsshim
am force-stop com.ss.android.ugc.trill
am force-stop com.google.android.contacts
am force-stop com.android.mms.service
am force-stop com.google.android.cellbroadcastreceiver
am force-stop com.miui.mediaviewer
am force-stop com.android.credentialmanager
am force-stop com.xiaomi.bluetooth.rro.device.config.overlay
am force-stop android.miui.overlay.telephony
am force-stop com.google.android.printservice.recommendation
am force-stop com.xiaomi.phone
am force-stop com.miui.safetycenter.res.overlay
am force-stop com.google.android.captiveportallogin
am force-stop com.google.android.networkstack
am force-stop com.xiaomi.micloud.sdk
am force-stop com.miui.phone.carriers.overlay.vodafone
am force-stop com.android.keychain
am force-stop com.google.android.overlay.gmsconfig.asi
am force-stop com.miui.global.packageinstaller
am force-stop com.qti.service.colorservice
am force-stop com.qualcomm.qti.qms.service.connectionsecurity
am force-stop com.qualcomm.qti.confdialer
am force-stop com.qualcomm.qti.devicestatisticsservice
am force-stop com.android.virtualmachine.res
am force-stop com.android.shell
am force-stop com.miui.safetycenter.config.overlay
am force-stop com.android.wifi.resources.xiaomi
am force-stop com.google.android.wifi.dialog
am force-stop com.android.inputdevices
am force-stop com.google.android.appsearch.apk
am force-stop com.google.android.ondevicepersonalization.services
am force-stop com.android.provision.esim.transfer.overlay
am force-stop com.android.providers.telephony.overlay.miui
am force-stop com.google.android.overlay.modules.healthfitness.forframework
am force-stop com.qti.qualcomm.datastatusnotification
am force-stop com.goodix.fingerprint.producttest
am force-stop com.miui.rom
am force-stop com.qti.dpmserviceapp
am force-stop com.google.android.onetimeinitializer
am force-stop com.google.android.permissioncontroller
am force-stop com.android.carrierconfig.overlay.miui
am force-stop com.miui.permissioncontroller.overlay
am force-stop com.google.android.wifi.resources.overlay.target
am force-stop com.android.sharedstoragebackup
am force-stop com.android.imsserviceentitlement
am force-stop com.qualcomm.qti.uimGbaApp
am force-stop com.qualcomm.qti.ridemodeaudio
am force-stop com.android.providers.media
am force-stop com.android.providers.calendar
am force-stop com.android.providers.blockednumber
am force-stop com.google.android.documentsui
am force-stop vendor.qti.qesdk.sysservice
am force-stop com.android.statementservice
am force-stop com.qualcomm.qti.ims
am force-stop com.google.android.overlay.modules.documentsui
am force-stop com.google.android.devicelockcontroller
am force-stop com.android.proxyhandler
am force-stop com.miui.settings.rro.device.hide.statusbar.overlay
am force-stop com.google.android.overlay.modules.permissioncontroller
am force-stop com.android.cellbroadcastreceiver.overlay.common
am force-stop com.android.managedprovisioning
am force-stop com.android.emergency
am force-stop com.miui.aod
am force-stop com.microsoftsdk.crossdeviceservicebroker
am force-stop com.android.carrierdefaultapp
am force-stop com.android.backupconfirm
am force-stop com.google.android.hotspot2.osulogin
am force-stop com.android.server.telecom.overlay.miui
am force-stop com.android.carrierconfig.overlay.common
am force-stop com.android.mtp
am force-stop com.google.android.gsf
am force-stop com.android.systemui.navigation.bar.overlay
am force-stop com.android.phone.auto_generated_characteristics_rro
am force-stop com.android.internal.display.cutout.emulation.double
am force-stop com.android.theme.font.notoserifsource
am force-stop com.qualcomm.qti.remoteSimlockAuth
am force-stop com.android.networkstack.overlay.miui
am force-stop com.google.android.health.connect.backuprestore
am force-stop com.android.server.telecom.overlay.common
am force-stop com.qualcomm.qti.xrvd.service
am force-stop com.qualcomm.qti.xrcb
am force-stop com.miui.guardprovider
am force-stop com.android.managedprovisioning.overlay
am force-stop com.google.android.wifi.resources.overlay.common
am force-stop com.google.android.dialer
am force-stop com.google.android.overlay.gmsconfig.geotz
am force-stop com.qualcomm.qti.uceShimService
am force-stop com.android.internal.systemui.navbar.gestural
am force-stop com.android.role.notes.enabled
am force-stop com.google.android.wifi.resources.xiaomi
am force-stop com.qti.xdivert
am force-stop com.qti.dcf
am force-stop com.miui.systemui.overlay.devices.android
am force-stop com.android.settings.intelligence
am force-stop com.qualcomm.timeservice
am force-stop com.qualcomm.qti.qcolor
am force-stop com.lbe.security.miui
am force-stop com.android.settings.overlay.miui
am force-stop com.miui.cleaner
am force-stop com.android.avatarpicker
am force-stop com.google.android.overlay.gmsconfig.personalsafety
am force-stop com.qualcomm.wfd.service
am force-stop com.android.overlay.gmssettings
am force-stop com.google.android.federatedcompute
am force-stop vendor.qti.imsrcs
am force-stop com.google.android.webview
am force-stop com.google.android.sdksandbox
am force-stop com.android.deskclock
am force-stop com.android.wallpaperbackup
am force-stop com.miui.securityadd
am force-stop com.google.android.cellbroadcastservice
am force-stop com.android.thememanager.customizethemeconfig.config.overlay
am force-stop com.android.internal.systemui.navbar.threebutton
am force-stop com.miui.core
am force-stop com.miui.settings.rro.device.type.overlay
am force-stop android
am force-stop com.xiaomi.touchservice
am force-stop com.google.android.overlay.modules.modulemetadata.forframework
am force-stop com.miui.gallery
am force-stop com.qualcomm.qti.dynamicddsservice
am force-stop com.google.android.packageinstaller
am force-stop com.android.se
am force-stop com.android.pacprocessor
am force-stop com.miui.phone.carriers.overlay.h3g
am force-stop com.google.android.safetycenter.resources
am force-stop com.android.internal.display.cutout.emulation.hole
am force-stop com.miui.calculator
am force-stop com.android.settings
am force-stop com.qualcomm.qti.telephonyservice
am force-stop com.google.android.partnersetup
am force-stop com.xiaomi.bluetooth
am force-stop com.android.internal.display.cutout.emulation.tall
am force-stop com.google.android.networkstack.tethering
am force-stop com.xiaomi.phone.overlay
am force-stop com.android.cameraextensions
am force-stop com.android.carrierconfig
am force-stop com.qualcomm.qti.simcontacts
am force-stop com.openai.chatgpt
am force-stop com.android.overlay.gmstelephony
am force-stop com.google.android.ext.shared
am force-stop com.xiaomi.xmsfkeeper
am force-stop com.miui.notification
am force-stop org.codeaurora.ims
am force-stop com.android.chrome
am force-stop com.qualcomm.qcrilmsgtunnel
am force-stop com.qualcomm.qti.biometrics.fingerprint.qfsfactorytest
am force-stop android.overlay.common
am force-stop com.android.compos.payload
am force-stop com.android.musicfx
am force-stop android.auto_generated_characteristics_rro
am force-stop com.android.internal.systemui.navbar.transparent
am force-stop android.aosp.overlay.telephony
am force-stop com.google.android.inputmethod.latin
am force-stop com.android.phone.cust.overlay.miui
am force-stop miui.systemui.plugin
am force-stop com.android.smspush
am force-stop vendor.qti.hardware.cacert.server
am force-stop com.xiaomi.cameratools
am force-stop com.google.android.wifi.resources
am force-stop com.android.ons
am force-stop com.scheler.superproxy
am force-stop com.mi.globallayout
am force-stop com.android.intentresolver
am force-stop com.xiaomi.ugd
am force-stop com.android.certinstaller
am force-stop com.miui.system
am force-stop com.qualcomm.uimremoteclient
am force-stop com.android.wifi.dialog
am force-stop com.qti.snapdragon.qdcm_ff
am force-stop com.qualcomm.atfwd2
am force-stop com.qualcomm.qti.server.qtiwifi
am force-stop com.miui.systemui.carriers.overlay
am force-stop com.miui.securitycenter
am force-stop com.android.simappdialog
am force-stop com.android.providers.telephony
am force-stop com.android.systemui.overlay.common
am force-stop org.telegram.messenger
am force-stop com.miui.settings.rro.device.config.overlay
am force-stop jp.konami.pesam
am force-stop com.qualcomm.qti.poweroffalarm
am force-stop com.xiaomi.aon
am force-stop com.android.internal.display.cutout.emulation.waterfall
am force-stop com.mobilechess.gp
am force-stop com.miui.qr
am force-stop com.android.providers.settings
am force-stop com.android.overlay.gmssettingprovider
am force-stop vendor.qti.iwlan
am force-stop com.xiaomi.cameramind
am force-stop com.android.phone
am force-stop com.google.android.overlay.modules.ext.services
am force-stop com.android.stk.overlay.miui
am force-stop com.android.uwb.resources.overlay.common
am force-stop com.android.systemui.gesture.line.overlay
am force-stop android.aosp.overlay
am force-stop com.android.bluetooth.overlay
am force-stop com.google.android.as.oss
am force-stop com.google.android.apps.messaging
am force-stop com.qualcomm.qti.services.systemhelper
am force-stop com.android.location.fused
am force-stop com.android.vpndialogs
am force-stop com.android.uwb.resources
am force-stop com.miui.screenshot
am force-stop com.google.android.overlay.gmsconfig.photos
am force-stop com.google.android.modulemetadata
am force-stop com.android.settings.overlay.common
am force-stop com.android.wifi.resources.overlay.common
am force-stop com.google.android.cellbroadcastreceiver.overlay.miui
am force-stop com.android.phone.overlay.common
am force-stop com.android.htmlviewer
am force-stop com.qti.qualcomm.deviceinfo
am force-stop com.android.vending
am force-stop com.miui.home
am force-stop com.google.android.ext.services
am force-stop com.google.android.configupdater
am force-stop com.google.android.overlay.modules.captiveportallogin.forframework
am force-stop android.overlay.target
am force-stop com.miui.system.overlay
am force-stop com.qti.qcc
am force-stop com.google.android.apps.turbo
am force-stop org.ifaa.aidl.manager
am force-stop com.android.providers.settings.overlay
am force-stop com.google.android.overlay.gmsconfig.gsa
am force-stop com.android.providers.userdictionary
am force-stop com.android.providers.contactkeys
am force-stop com.google.android.overlay.gmsconfig.common
am force-stop com.google.android.server.deviceconfig.resources
am force-stop com.android.cts.ctsshim
am force-stop com.android.bluetooth
am force-stop io.uax.myip
am force-stop com.qualcomm.qti.workloadclassifier
am force-stop com.android.internal.display.cutout.emulation.corner
am force-stop com.google.android.gms
am force-stop com.android.storagemanager
am force-stop com.android.systemui.overlay.miui
am force-stop com.txhai.myip.ipaddress.speedtest
am force-stop com.android.inputsettings.overlay.miui
am force-stop com.android.phone.overlay.miui
am force-stop com.miui.systemui.devices.overlay
am force-stop com.xiaomi.misettings
am force-stop vendor.qti.bluetooth.xpan.overlay.target
am force-stop com.android.wifi.resources.overlay.target
am force-stop com.miui.misound
am force-stop com.android.se.overlay.target
am force-stop com.qualcomm.qti.uim
am force-stop com.android.providers.partnerbookmarks
am force-stop com.android.soundpicker
am force-stop com.android.provision
am force-stop com.google.mainline.telemetry
am force-stop com.google.android.euicc
am force-stop com.qualcomm.qti.qms.service.trustzoneaccess
am force-stop com.facebook.katana
am force-stop com.android.dynsystem
am force-stop com.android.angle
am force-stop com.android.microdroid.empty_payload
am force-stop moe.shizuku.privileged.api
am force-stop com.speedsoftware.rootexplorer
am force-stop vendor.qti.data.txpwradmin
am force-stop com.android.providers.telephony.auto_generated_characteristics_rro
am force-stop com.google.android.overlay.devicelockcontroller
am force-stop com.google.android.apps.adm
am force-stop com.google.android.connectivity.resources
am force-stop com.google.android.cellbroadcastservice.overlay.miui
am force-stop com.android.externalstorage
am force-stop vendor.qti.imsdatachannel
am force-stop com.android.server.telecom
) > /dev/null 2>&1 &

echo "Ram Booster active - Universal Adaptive Mode"

sleep 0.5

echo ""
echo "INSTALLATION COMPLETED! RAM BOOSTER"
sleep 0.5

echo ""
echo "GAMING MODE ACTIVE - RAM OPTIMIZATION MODULE"

sleep 0.5

echo ""
echo "THANKS FOR USING RAM BOOSTER BY AGUNG DEVELOPER"
echo ""

cmd notification post -S bigtext -t 'RAM BOOSTER' 'Gaming Boost' 'RAM Optimization Success!' > /dev/null 2>&1 &