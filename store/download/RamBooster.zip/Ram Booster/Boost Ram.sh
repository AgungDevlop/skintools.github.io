#!/bin/bash

# Ram Booster - Universal Adaptive RAM Tweaks by Agung Developer (Non-Root Version)

# Save installation date
date '+%Y-%m-%d %H:%M:%S' > /data/local/tmp/ram_booster_install_date 2>/dev/null || echo "Unable to save installation date"

INSTALL_DATE=$(cat /data/local/tmp/ram_booster_install_date 2>/dev/null || echo "Unknown")

# Display device information
echo "---------------------------------------------"
echo "|         DEVICE AND HARDWARE INFO          |"
echo "---------------------------------------------"
echo "| Device   : $(getprop ro.product.manufacturer 2>/dev/null || echo 'Unknown') $(getprop ro.product.model 2>/dev/null || echo 'Unknown') |"
echo "| CPU      : $(getprop ro.board.platform 2>/dev/null || echo 'Unknown') |"
echo "| GPU      : $(getprop ro.hardware 2>/dev/null || echo 'Unknown') |"
echo "| Android  : $(getprop ro.build.version.release 2>/dev/null || echo 'Unknown') |"
echo "| Install  : $INSTALL_DATE |"
echo "| Kernel   : $(uname -r 2>/dev/null || echo 'Unknown') |"
echo "| Build    : $(getprop ro.build.display.id 2>/dev/null || echo 'Unknown') |"
echo "| Root     : No (Non-root mode) |"
echo "| SELinux  : $(getenforce 2>/dev/null || echo 'Unknown') |"
echo "---------------------------------------------"

echo ""
echo "=== WELCOME TO RAM BOOSTER INSTALLATION ==="
echo ""
sleep 1

# Check if required commands are available
if ! command -v settings >/dev/null 2>&1 || ! command -v am >/dev/null 2>&1 || ! command -v pm >/dev/null 2>&1; then
    echo "Error: Required commands (settings, am, or pm) not found. This script requires ADB with proper permissions."
    exit 1
fi

# INSTALLATION PROCESS
echo "Starting RAM optimization..."
sleep 1
echo "Optimizing system settings..."
sleep 1

# Apply safe system settings (non-root accessible)
{
    settings put global animator_duration_scale 0.5 2>/dev/null || echo "Warning: Unable to set animator_duration_scale"
    settings put global transition_animation_scale 0.5 2>/dev/null || echo "Warning: Unable to set transition_animation_scale"
    settings put global window_animation_scale 0.5 2>/dev/null || echo "Warning: Unable to set window_animation_scale"
    settings put global wifi_scan_always_enabled 0 2>/dev/null || echo "Warning: Unable to set wifi_scan_always_enabled"
    settings put secure adaptive_sleep 0 2>/dev/null || echo "Warning: Unable to set adaptive_sleep"
    settings put secure screensaver_enabled 0 2>/dev/null || echo "Warning: Unable to set screensaver_enabled"
} &

# Calculate adaptive settings based on total RAM
TOTAL_RAM=$(free -m 2>/dev/null | awk '/Mem:/ {print $2}' || echo 0)
if [ "$TOTAL_RAM" -eq 0 ]; then
    echo "Warning: Unable to detect total RAM. Using default settings."
    MAX_CACHED=16
    BG_LOW_MEM_MULT=1
else
    MAX_CACHED=$((TOTAL_RAM / 256))
    BG_LOW_MEM_MULT=$((TOTAL_RAM <= 4096 ? 3 : TOTAL_RAM <= 8192 ? 2 : 1))
fi

# Apply adaptive RAM settings (non-root safe)
{
    settings put global activity_manager_constants "max_cached_processes=$MAX_CACHED" 2>/dev/null || echo "Warning: Unable to set max_cached_processes"
    settings put global low_ram $( [ "$TOTAL_RAM" -le 4096 ] && echo true || echo false ) 2>/dev/null || echo "Warning: Unable to set low_ram"
} &

# Close background apps (user-installed apps only, excluding critical ones)
echo "Closing background apps..."
sleep 1
for app in $(pm list packages -3 2>/dev/null | cut -f 2 -d ":" | grep -v -E 'brevent|hackendebug|whatsapp|omarea.vtools|miHoYo.GenshinImpact|dts.freefiremax|dts.freefireth|tencent.ig|mobile.legends'); do
    echo "Force stopping $app"
    am force-stop --user 0 "$app" 2>/dev/null || echo "Warning: Unable to stop $app"
    sleep 0.1
done &

# Clean up temporary files
TMP_SCRIPT="/data/local/tmp/ram_booster"
rm -f "$TMP_SCRIPT" 2>/dev/null

echo "Ram Booster active - Universal Adaptive Mode (Non-Root)"
sleep 0.5

echo ""
echo "INSTALLATION COMPLETED! RAM BOOSTER"
sleep 0.5

echo ""
echo "GAMING MODE ACTIVE - RAM OPTIMIZATION MODULE"
sleep 0.5

echo ""
echo "THANKS FOR USING RAM BOOSTER BY AGUNG DEVELOPER"
echo ""

# Post notification (if supported)
cmd notification post -S bigtext -t 'RAM BOOSTER' 'Gaming Boost' 'RAM Optimization Success!' 2>/dev/null &