#!/bin/bash

# Ram Booster Uninstall - Reset to Default by Agung Developer

# Save uninstallation date
date '+%Y-%m-%d %H:%M:%S' > /data/local/tmp/ram_booster_uninstall_date

INSTALL_DATE=$(cat /data/local/tmp/ram_booster_uninstall_date 2>/dev/null || echo "Unknown")

echo "---------------------------------------------"
echo "|         DEVICE AND HARDWARE INFO          |"
echo "---------------------------------------------"
echo "| Device   : $(getprop ro.product.manufacturer) $(getprop ro.product.model) |"
echo "| CPU      : $(getprop ro.board.platform) |"
echo "| GPU      : $(getprop ro.hardware) |"
echo "| Android  : $(getprop ro.build.version.release) |"
echo "| Install  : $INSTALL_DATE |"
echo "| Kernel   : $(uname -r) |"
echo "| Build    : $(getprop ro.build.display.id) |"
echo "| Root     : $(if [ $(id -u) -eq 0 ]; then echo 'Yes'; else echo 'No'; fi) |"
echo "| SELinux  : $(getenforce) |"
echo "---------------------------------------------"

echo ""
echo "=== WELCOME TO RAM BOOSTER UNINSTALL ==="
echo ""
sleep 0.5

# UNINSTALLATION PROCESS
echo "Starting system restoration..."
sleep 1
echo "Resetting system settings to default..."
sleep 1
echo ""
(
# Reset animations to default
settings put global animator_duration_scale 1
settings put global transition_animation_scale 1
settings put global window_animation_scale 1
# Reset activity manager
settings delete global activity_manager_constants
settings delete global settings_enable_monitor_phantom_procs
settings delete global limit_background_processes
# Reset dexopt
settings delete global bg_dexopt
# Reset SPCM
settings delete global config.spcm_enable
settings delete global config.spcm_kill_skip
settings delete global config.samp_spcm_enable
settings delete global config.spcm_db_enable
settings delete global config.spcm_db_launcher
settings delete global config.spcm_preload_enable
settings delete global config.spcm_gcm_kill_enable
# Reset DHA
settings delete global config.dha_cached_max
settings delete global config.dha_empty_max
settings delete global config.dha_empty_init
settings delete global config.dha_lmk_scale
settings delete global config.dha_th_rate
settings delete global config.sdha_apps_bg_max
settings delete global config.sdha_apps_bg_min
# Re-enable tombstoned
pm enable com.android.shell.tombstoned
start tombstoned
# Reset resource consumption settings
settings delete global activity_starts_logging_enabled
settings delete global ble_scan_always_enabled
settings delete global hotword_detection_enabled
settings delete global mobile_data_always_on
settings delete global network_recommendations_enabled
settings delete global wifi_scan_always_enabled
settings delete secure adaptive_sleep
settings delete secure screensaver_activate_on_dock
settings delete secure screensaver_activate_on_sleep
settings delete secure screensaver_enabled
settings delete secure send_action_app_error
settings delete system intelligent_sleep_mode
settings delete system master_motion
settings delete system motion_engine
settings delete system nearby_scanning_enabled
settings delete system nearby_scanning_permission_allowed
settings delete system rakuten_denwa
settings delete system send_security_reports
# Reset adaptive RAM tweaks
settings delete global low_ram
settings delete global force_low_ram_device
settings delete system sys.haptic.low_ram
settings delete global swap_free_low_percentage
settings delete global zram_enable
settings delete global zram_size
# Reset vm drop caches
settings delete system vm_drop_caches
# Reset force stop apps setting
settings delete system force_all_apps_stopped
) > /dev/null 2>&1 &

echo "Ram Booster has been removed & settings restored to default."

echo ""
echo "Resetting Ram Booster"
echo ""
sleep 0.5
echo ""
echo "ALL SETTINGS RESTORED"
echo ""
sleep 0.5
echo ""
echo "REMOVING ALL TWEAKS"
echo ""
sleep 0.5
echo ""
echo "AGUNG DEVELOPER"
echo ""
sleep 0.5
echo ""
echo "THANKS FOR USING RAM BOOSTER"
echo ""
sleep 0.5
echo ""
echo "=== THANKS FOR USING MODULE ==="
echo ""

cmd notification post -S bigtext -t 'RAM BOOSTER' 'Uninstall' 'Successfully Removed.' > /dev/null 2>&1 &