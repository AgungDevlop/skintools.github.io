#!/bin/bash

# Warna untuk tampilan
GREEN='\033[0;32m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Fungsi untuk membuat garis pemisah
print_separator() {
    echo -e "${CYAN}══════════════════════════════════════════════${NC}"
}

# Header
clear
echo -e "${GREEN}===== Informasi RAM Sistem ====="
print_separator

# Mendapatkan informasi RAM dari /proc/meminfo
mem_total=$(grep MemTotal /proc/meminfo | awk '{print $2}')
mem_free=$(grep MemFree /proc/meminfo | awk '{print $2}')
mem_available=$(grep MemAvailable /proc/meminfo | awk '{print $2}')
mem_used=$((mem_total - mem_free))
mem_buffers=$(grep Buffers /proc/meminfo | awk '{print $2}')
mem_cached=$(grep Cached /proc/meminfo | awk '{print $2}')

# Konversi ke MB
mem_total_mb=$(echo "scale=2; $mem_total/1024" | bc)
mem_free_mb=$(echo "scale=2; $mem_free/1024" | bc)
mem_available_mb=$(echo "scale=2; $mem_available/1024" | bc)
mem_used_mb=$(echo "scale=2; $mem_used/1024" | bc)
mem_buffers_mb=$(echo "scale=2; $mem_buffers/1024" | bc)
mem_cached_mb=$(echo "scale=2; $mem_cached/1024" | bc)

# Persentase penggunaan RAM
mem_used_percent=$(echo "scale=2; ($mem_used/$mem_total)*100" | bc)

# Menampilkan informasi RAM
echo -e "${BLUE}Total RAM:${NC}        ${mem_total_mb} MB"
echo -e "${BLUE}RAM Digunakan:${NC}   ${mem_used_mb} MB (${mem_used_percent}%)"
echo -e "${BLUE}RAM Bebas:${NC}       ${mem_free_mb} MB"
echo -e "${BLUE}RAM Tersedia:${NC}    ${mem_available_mb} MB"
echo -e "${BLUE}Buffers:${NC}         ${mem_buffers_mb} MB"
echo -e "${BLUE}Cached:${NC}          ${mem_cached_mb} MB"

print_separator
echo -e "${GREEN}Selesai${NC}"