echo ""
echo "█▓▒▒░░░ Game Turbo Extreme ░░░▒▒▓█"
echo ""
sleep 1
echo "MODUL INI DIRANCANG UNTUK PERFORMA EKSTRIM"
echo "AUTOR: Agung Developer"
echo ""
sleep 1
echo "→ Menganalisis Arsitektur Perangkat..."
sleep 0.5
echo "DEVICE: $(getprop ro.product.brand) $(getprop ro.product.model)"
echo "CPU_ABI: $(getprop ro.product.cpu.abi)"
echo "RENDERER: $(getprop ro.hardware.egl)"
echo "SDK_VERSION: $(getprop ro.build.version.sdk)"
echo ""
echo "█▓▒▒░░░ MEMULAI INJEKSI PERFORMA ULTIMATE ░░░▒▒▓█"
echo ""
sleep 1

echo "→ [FASE 1/5] Prosedur Pembersihan Sistem Agresif..."
pm trim-caches 9999999999 > /dev/null 2>&1
sync && echo 3 > /proc/sys/vm/drop_caches > /dev/null 2>&1
for app in $(pm list packages -3 | cut -f 2 -d ":"); do am force-stop $app; done
sleep 0.5
echo "Pembersihan Sistem Selesai."
echo ""

echo "→ [FASE 2/5] Kalibrasi Ulang Sistem Inti, CPU & GPU..."
cmd power set-fixed-performance-mode-enabled true > /dev/null 2>&1
cmd game mode performance global > /dev/null 2>&1
settings put system bench_mark_mode 1
(
setprop debug.performance.tuning 1
setprop debug.power.throttling.disable 1
setprop persist.sys.performance.level 4
setprop ro.kernel.android.checkjni 0
setprop ro.lmk.kill_heaviest_task true
setprop persist.sys.purgeable_assets 1
setprop ro.config.hw_power_saving 0
setprop ro.media.enc.jpeg.quality 100
setprop ro.ril.power_collapse 1
setprop profiler.force_disable_ulog true
setprop profiler.force_disable_err_rpt true
setprop logcat.live disable
) > /dev/null 2>&1
sleep 0.5
echo "Sistem Inti Telah Dikalibrasi Ulang."
echo ""

echo "→ [FASE 3/5] Optimasi Tampilan, FPS & Mesin Render Vulkan..."
settings put system peak_refresh_rate 999.0
settings put system min_refresh_rate 90.0
(
setprop debug.sf.set_fps 999
setprop debug.gralloc.max_fps 999
setprop debug.hwui.renderer vulkan
setprop ro.hwui.use_vulkan true
setprop debug.angle.backend vulkan
setprop debug.sf.hw 1
setprop debug.egl.hw 1
setprop persist.sys.ui.hw true
setprop debug.composition.type gpu
setprop debug.egl.swapinterval 0
setprop video.accelerate.hw 1
setprop ro.surface_flinger.max_frame_buffer_acquired_buffers 3
setprop debug.sf.latch_unsignaled 1
setprop windowsmgr.max_events_per_sec 240
) > /dev/null 2>&1
sleep 0.5
echo "Mesin Render & Tampilan Telah Dioptimalkan."
echo ""

echo "→ [FASE 4/5] Peningkatan Jaringan & I/O Laten Rendah..."
(
setprop net.tcp.buffersize.default 6144,87380,1048576,6144,87380,1048576
setprop net.tcp.buffersize.wifi 4096,262144,3145728,4096,262144,3145728
setprop net.tcp.buffersize.lte 524288,1048576,2097152,524288,1048576,2097152
setprop net.tcp.buffersize.umts 4096,87380,110208,4096,16384,110208
setprop net.tcp.buffersize.hspa 4096,87380,1220608,4096,16384,1220608
setprop net.ipv4.tcp_fastopen 3
setprop net.ipv4.tcp_syncookies 1
setprop net.ipv4.tcp_tw_reuse 1
setprop net.ipv4.tcp_timestamps 1
) > /dev/null 2>&1
sleep 0.5
echo "Jaringan Telah Dioptimalkan untuk Gaming."
echo ""

echo "→ [FASE 5/5] Penonaktifan Manajemen Thermal Secara Ekstrim..."
cmd thermalservice override-status 0 > /dev/null 2>&1
settings put global thermal_throttling 0
(
setprop ctl.stop thermald
setprop ctl.stop thermal-engine
setprop ctl.stop thermal_manager
setprop debug.init.svc.thermald stopped
setprop debug.init.svc.thermal-engine stopped
setprop debug.init.svc.thermal_manager stopped
setprop debug.thermal_zone.gpu_threshold_temp 99
setprop debug.thermal_zone.cpu_threshold_temp 99
setprop debug.thermal_zone.battery_threshold_temp 65
setprop debug.thermal.cpu_thermal_throttle.disable 1
setprop debug.thermal.gpu_thermal_throttle.disable 1
setprop debug.thermal.gpu_core_clock_throttle.disable 1
setprop debug.thermal.gpu_shader_clock_throttle.disable 1
setprop debug.thermal.throttling.disable 1
setprop debug.thermal.auto_thermal_disable 1
setprop debug.thermal.zone.disabled 1
setprop debug.thermal.suspend.disabled 1
setprop debug.thermal.trip_point.disabled 1
setprop debug.thermal.thermal_policy.disable 1
setprop debug.thermal.balance_algorithm 0
setprop debug.thermal.performance_mode.disable 1
setprop debug.thermal.overheat_protection.disable 1
setprop debug.thermal.shutdown.disable 1
) > /dev/null 2>&1
sleep 0.5
echo "Manajemen Thermal Dinonaktifkan."
echo ""

sleep 1
echo "█▓▒▒░░░ INJEKSI PERFORMA EKSTRIM TELAH SELESAI [✓] ░░░▒▒▓█"
echo ""
sleep 0.5
echo "‼️ PERINGATAN: JANGAN REBOOT PERANGKAT ANDA UNTUK MENJAGA EFEK ‼️"
echo ""
sleep 1
echo "ENJOY YOUR EXTREME GAMING EXPERIENCE"
echo ""
sleep 0.5
cmd notification post -S bigtext -t 'Game Turbo Extreme' 'Tag' 'SUKSES DIAKTIFKAN. Autor Agung Developer.'