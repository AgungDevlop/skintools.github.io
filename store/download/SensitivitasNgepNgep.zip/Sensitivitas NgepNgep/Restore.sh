#!/bin/bash
echo ""
echo "[ RESTORING SYSTEM SETTINGS ]"
sleep 1.5
echo "[■□□□□□□□□□]  "
sleep 0.7
echo "[■■□□□□□□□□]  "
sleep 1
echo "[■■■□□□□□□□]  "
sleep 1
echo "[■■■■□□□□□□]  "
sleep 1
echo "[■■■■■□□□□□]  "
sleep 1
echo "[■■■■■■□□□□]  "
sleep 1
echo "[■■■■■■■□□□]  "
sleep 1
echo "[■■■■■■■■□□]  "
sleep 1
echo "[■■■■■■■■■□] "
sleep 1
echo "[■■■■■■■■■■] "
echo ""

# Mengembalikan resolusi layar dan DPI ke default (otomatis)
echo " RESTORING SCREEN RESOLUTION AND DPI "
wm size reset
wm density reset
sleep 1

# Mengembalikan pengaturan sensitivitas layar
echo " RESTORING TOUCH SENSITIVITY "
(
settings put system touch_sensitivity 0
setprop persist.sys.touch.responsiveness 0
setprop persist.sys.touch.pressed_threshold ""
setprop debug.input.touch.filter ""
setprop persist.sys.touch.sampling_rate ""  # Mengembalikan sampling rate sentuhan
setprop debug.input.touch.latency ""  # Mengembalikan latensi sentuhan
cmd device_config put input_native_boot touch.input.ignore_events ""
cmd device_config put input_native_boot touch.input.pressure.scale ""
cmd device_config put input_native_boot touch.input.size.scale ""
cmd device_config put input_native_boot touch.input.velocity.scale ""  # Mengembalikan skala kecepatan sentuhan
cmd device_config put touchscreen input_drag_min_switch_speed ""
)> /dev/null 2>&1
sleep 1

# Mengembalikan pengaturan refresh rate
echo " RESTORING REFRESH RATE "
settings put system min_refresh_rate 0
settings put system peak_refresh_rate 0
settings put system user_refresh_rate 0
sleep 1

# Mengembalikan pengaturan game mode dan optimasi aplikasi
echo " RESTORING GAME MODE AND APP OPTIMIZATIONS "
(
dumpsys deviceidle whitelist -com.dts.freefireth
dumpsys deviceidle whitelist -com.dts.freefiremax
appops set com.dts.freefireth RUN_IN_BACKGROUND ignore
appops set com.dts.freefiremax RUN_IN_BACKGROUND ignore
cmd sensorservice reset-uid-state com.dts.freefireth
cmd sensorservice reset-uid-state com.dts.freefiremax
pm log-visibility --enable com.dts.freefireth
pm log-visibility --enable com.dts.freefiremax
cmd game mode standard com.dts.freefireth
cmd game mode standard com.dts.freefiremax
cmd game mode standard com.mobile.legends
cmd game mode standard com.tencent.ig
cmd game mode standard com.garena.game.codm
cmd game mode standard com.miHoYo.GenshinImpact
cmd game mode standard com.mobilelegends.hwag
cmd game mode standard com.netease.newspike
cmd package compile --reset com.dts.freefireth
cmd package compile --reset com.dts.freefiremax
)> /dev/null 2>&1
sleep 1

# Mengembalikan pengaturan performa dan responsivitas
echo " RESTORING PERFORMANCE SETTINGS "
(
etc 0 zen_mode> /dev/null 2>&1
etc DISABLE sem_enhanced_cpu_responsiveness> /dev/null 2>&1
sensi 0 screen_game_mode> /dev/null 2>&1
sensi 0 perf_game_oom_enable> /dev/null 2>&1
sensi "" rt_templimit_bottom> /dev/null 2>&1
sensi "" rt_templimit_ceiling> /dev/null 2>&1
game 0 speed_mode_enable> /dev/null 2>&1
etc 0 ambient_low_bit_enabled> /dev/null 2>&1
etc 0 ambient_low_bit_enabled_dev> /dev/null 2>&1
game "" aim_lock_timeout> /dev/null 2>&1
settings put system view.scroll_friction ""
settings put secure multi_press_timeout 300
settings put secure long_press_timeout 500
)> /dev/null 2>&1
sleep 1

# Mengembalikan pengaturan jaringan
echo " RESTORING NETWORK SETTINGS "
(
settings put global wifi_score_params ""
settings put global wifi_coverage_extend_feature_enabled ""
settings put global wifi_networks_available_notification_on ""
settings put global wifi_poor_connection_warning ""
settings put global wifi_scan_always_enabled ""
settings put global wifi_scan_throttle_enabled ""
settings put global wifi_verbose_logging_enabled ""
settings put global wifi_suspend_optimizations_enabled ""
settings put global wifi_wakeup_enabled ""
settings put global sysui_powerui_enabled ""
settings put global ble_scan_always_enabled ""
)> /dev/null 2>&1
sleep 1

# Mengembalikan pengaturan grafis dan FPS
echo " RESTORING GRAPHICS AND FPS SETTINGS "
(
setprop debug.egl.force_msaa ""
setprop debug.egl.force_fxaa ""
setprop debug.egl.force_taa ""
setprop debug.egl.force_ssaa ""
setprop debug.egl.force_smaa ""
setprop debug.egl.hw ""
setprop debug.egl.buffcount ""
settings put global video.accelerate.hw 0
settings put global persist.cpu.gov.performance ""
settings put global game_driver_prerelease_opt_in_apps ""
)> /dev/null 2>&1
sleep 1

echo ""
echo "SYSTEM RESTORED SUCCESSFULLY"