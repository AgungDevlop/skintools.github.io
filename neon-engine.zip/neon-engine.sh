#!/data/data/com.termux/files/usr/bin/sh
set -u
R='\033[1;31m'
G='\033[1;32m'
Y='\033[1;33m'
B='\033[1;34m'
C='\033[1;36m'
M='\033[1;35m'
W='\033[1;37m'
N='\033[0m'
BASE_URL='https://raw.githubusercontent.com/Magisk-Modules-Repo/busybox-ndk/master'
ROOT="$HOME/.neon-engine"
BIN="$ROOT/bin"
WEB="$ROOT/web"
CGI="$WEB/cgi-bin"
BB="$BIN/busybox"
PUBLIC='/sdcard/Download'
PUBLIC_BB="$PUBLIC/busybox"
CLIENT="${PREFIX:-/data/data/com.termux/files/usr}/bin/neon"
say(){ printf '%b\n' "$1"; }
line(){ printf '%b\n' "${C}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${N}"; }
fail(){ say "${R}[!] $1${N}"; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }
clear 2>/dev/null || true
say "${M}"
say ' _   _                  ____'
say '| \ | | ___  ___  _ __ / ___|___  _ __ ___'
say '|  \| |/ _ \/ _ \| _  \ |   / _ \| __/ _ \'
say '| |\  |  __/ (_) | | | | |__| (_) | | |  __/'
say '|_| \_|\___|\___/|_| |_|\____\___/|_|  \___|'
say '        N E O N   C O R E   E N G I N E'
say "${N}"
line
say "${B}[1/7] Menyiapkan ruang kerja...${N}"
have curl || fail 'curl belum terpasang. Jalankan: pkg install curl -y'
mkdir -p "$BIN" "$WEB" "$CGI" || fail 'Gagal membuat folder engine.'
say "${G}[✓] Folder siap${N}"
line
say "${B}[2/7] Memeriksa storage...${N}"
if [ ! -d "$PUBLIC" ]; then
  if have termux-setup-storage; then termux-setup-storage >/dev/null 2>&1 || true; sleep 2; fi
fi
[ -d "$PUBLIC" ] || fail 'Storage belum aktif. Izinkan storage Termux lalu jalankan ulang.'
say "${G}[✓] Storage siap${N}"
line
say "${B}[3/7] Memasang API documentation page...${N}"
SRC_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" 2>/dev/null && pwd)"
[ -f "$SRC_DIR/webgui.html" ] || fail 'webgui.html tidak ditemukan. Extract ZIP dulu, lalu jalankan neon-engine.sh dari folder hasil extract.'
cp "$SRC_DIR/webgui.html" "$WEB/index.html" || fail 'Gagal memasang halaman dokumentasi API.'
say "${G}[✓] API documentation page siap${N}"
line
say "${B}[4/7] Mendeteksi arsitektur...${N}"
ABI="$(getprop ro.product.cpu.abi 2>/dev/null || true)"
case "$ABI" in
  arm64-v8a) ENGINE_FILE='busybox-arm64' ;;
  armeabi-v7a|armeabi) ENGINE_FILE='busybox-arm' ;;
  x86) ENGINE_FILE='busybox-x86' ;;
  x86_64) ENGINE_FILE='busybox-x86_64' ;;
  *) U="$(uname -m 2>/dev/null || true)"; case "$U" in aarch64|arm64*) ENGINE_FILE='busybox-arm64' ;; armv7*|arm*) ENGINE_FILE='busybox-arm' ;; i*86) ENGINE_FILE='busybox-x86' ;; x86_64) ENGINE_FILE='busybox-x86_64' ;; *) ENGINE_FILE='busybox-arm64' ;; esac ;;
esac
say "${G}[✓] ABI: ${ABI:-unknown}${N}"
say "${G}[✓] Paket: $ENGINE_FILE${N}"
line
say "${B}[5/7] Mengunduh BusyBox pendukung...${N}"
rm -f "$BB" "$PUBLIC_BB"
curl -L --fail --connect-timeout 15 --max-time 180 --retry 3 --retry-delay 2 "$BASE_URL/$ENGINE_FILE" -o "$BB" || fail 'Download BusyBox gagal.'
SIZE="$(wc -c < "$BB" 2>/dev/null || echo 0)"
[ "$SIZE" -gt 100000 ] || fail 'File BusyBox tidak valid.'
chmod 755 "$BB" || fail 'chmod BusyBox gagal.'
cp "$BB" "$PUBLIC_BB" || fail 'Gagal menyalin BusyBox ke storage publik.'
chmod 755 "$PUBLIC_BB" 2>/dev/null || true
say "${G}[✓] BusyBox siap${N}"
line
say "${B}[6/7] Membuat command neon...${N}"
cat > "$CLIENT" <<'CLIENT_EOF'
#!/data/data/com.termux/files/usr/bin/sh
set -u
HOST='127.0.0.1'
DAEMON_PORT='45555'
WEB_PORT='8787'
ROOT="$HOME/.neon-engine"
BIN="$ROOT/bin"
BB="$BIN/busybox"
WEB="$ROOT/web"
CGI="$WEB/cgi-bin"
CATALOG="$ROOT/shell.json"
MODULE_DIR='/sdcard/Download/NeonEngine/modules'
OUT_DIR='/sdcard/Download/NeonEngine'
BASE_WEB='https://neonmagisk.my.id/tweak'
CATALOG_URL='https://neonmagisk.my.id/tweak/shell.json'
RED='\033[1;31m'; GREEN='\033[1;32m'; YELLOW='\033[1;33m'; BLUE='\033[1;34m'; CYAN='\033[1;36m'; MAG='\033[1;35m'; WHITE='\033[1;37m'; NC='\033[0m'
p(){ printf '%b\n' "$1"; }
hr(){ printf '%b\n' "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; }
need_dirs(){ mkdir -p "$ROOT" "$BIN" "$WEB" "$CGI" "$MODULE_DIR" "$OUT_DIR/dump" "$OUT_DIR/log" "$OUT_DIR/apk" "$OUT_DIR/media" "$OUT_DIR/report" 2>/dev/null || true; }
enc(){ printf '%s' "$1" | sed 's/ /%20/g'; }
send_cmd(){ CMD="$*"; [ -n "$CMD" ] || return 1; if [ -x "$BB" ]; then printf '%s\n' "$CMD" | "$BB" nc -w 55 "$HOST" "$DAEMON_PORT"; return $?; fi; if command -v nc >/dev/null 2>&1; then printf '%s\n' "$CMD" | nc -w 55 "$HOST" "$DAEMON_PORT"; return $?; fi; if command -v toybox >/dev/null 2>&1; then printf '%s\n' "$CMD" | toybox nc -w 55 "$HOST" "$DAEMON_PORT"; return $?; fi; p "${RED}[!] Netcat tidak tersedia. Jalankan ulang installer.${NC}"; return 1; }
daemon_alive(){ OUT="$(send_cmd 'echo NEON_READY' 2>/dev/null || true)"; printf '%s' "$OUT" | grep -q 'NEON_READY'; }
need_daemon(){ if ! daemon_alive; then p "${RED}[!] Engine belum aktif.${NC}"; p "${YELLOW}[!] Aktifkan Neon Core, lalu jalankan: neon install${NC}"; exit 1; fi; }
refresh(){ need_dirs; curl -L --fail --connect-timeout 15 --max-time 120 "$CATALOG_URL" -o "$CATALOG" >/dev/null 2>&1 || { p "${RED}[!] Gagal mengambil daftar module.${NC}"; return 1; }; COUNT="$(grep -c '"id"' "$CATALOG" 2>/dev/null || echo 0)"; p "${GREEN}[✓] Catalog diperbarui: $COUNT module${NC}"; }
field(){ ID="$1"; KEY="$2"; awk -v id="$ID" -v key="$KEY" 'BEGIN{RS="\\},";FS="\n"} $0~"\"id\"[[:space:]]*:[[:space:]]*\""id"\""{for(i=1;i<=NF;i++){if($i~"\""key"\""){x=$i;sub(/^[^:]*:[[:space:]]*\"/,"",x);sub(/\",?[[:space:]]*$/,"",x);print x;exit}}}' "$CATALOG" 2>/dev/null; }
modules(){ [ -s "$CATALOG" ] || refresh >/dev/null 2>&1 || return 1; awk 'BEGIN{RS="\\},";FS="\n"} {id="";title="";cat="";tier="";for(i=1;i<=NF;i++){x=$i;if(x~"\"id\""){sub(/^[^:]*:[[:space:]]*\"/,"",x);sub(/\",?[[:space:]]*$/,"",x);id=x} x=$i;if(x~"\"title\""){sub(/^[^:]*:[[:space:]]*\"/,"",x);sub(/\",?[[:space:]]*$/,"",x);title=x} x=$i;if(x~"\"category\""){sub(/^[^:]*:[[:space:]]*\"/,"",x);sub(/\",?[[:space:]]*$/,"",x);cat=x} x=$i;if(x~"\"tier\""){sub(/^[^:]*:[[:space:]]*\"/,"",x);sub(/\",?[[:space:]]*$/,"",x);tier=x}} if(id!="") printf "%-12s | %-42s | %-18s | %s\n",id,title,cat,tier}' "$CATALOG" | ${PAGER:-cat}; }
search_mod(){ Q="${1:-}"; [ -n "$Q" ] || { p 'Isi kata kunci module.'; return 1; }; [ -s "$CATALOG" ] || refresh >/dev/null 2>&1 || return 1; awk -v q="$Q" 'BEGIN{RS="\\},";FS="\n";q=tolower(q)} {rec=tolower($0); if(index(rec,q)){id="";title="";cat="";for(i=1;i<=NF;i++){x=$i;if(x~"\"id\""){sub(/^[^:]*:[[:space:]]*\"/,"",x);sub(/\",?[[:space:]]*$/,"",x);id=x} x=$i;if(x~"\"title\""){sub(/^[^:]*:[[:space:]]*\"/,"",x);sub(/\",?[[:space:]]*$/,"",x);title=x} x=$i;if(x~"\"category\""){sub(/^[^:]*:[[:space:]]*\"/,"",x);sub(/\",?[[:space:]]*$/,"",x);cat=x}} printf "%-12s | %-48s | %s\n",id,title,cat}}' "$CATALOG"; }
info_mod(){ ID="$1"; [ -n "$ID" ] || { p 'Isi ID module.'; return 1; }; [ -s "$CATALOG" ] || refresh >/dev/null 2>&1 || return 1; TITLE="$(field "$ID" title)"; [ -n "$TITLE" ] || { p "${RED}[!] Module tidak ditemukan: $ID${NC}"; return 1; }; p "ID       : $ID"; p "Nama     : $TITLE"; p "Kategori : $(field "$ID" category)"; p "Tier     : $(field "$ID" tier)"; p "Versi    : $(field "$ID" version)"; p "Support  : $(field "$ID" support)"; p "Deskripsi: $(field "$ID" description)"; }
get_mod(){ ID="$1"; need_dirs; [ -n "$ID" ] || { p 'Isi ID module.'; return 1; }; [ -s "$CATALOG" ] || refresh >/dev/null 2>&1 || return 1; URL_PATH="$(field "$ID" downloadUrl)"; TITLE="$(field "$ID" title)"; [ -n "$URL_PATH" ] || { p "${RED}[!] Module tidak ditemukan: $ID${NC}"; return 1; }; URL="$(enc "$BASE_WEB/$URL_PATH")"; DEST="$MODULE_DIR/$ID.zip"; DIR="$MODULE_DIR/$ID"; rm -rf "$DIR"; mkdir -p "$DIR"; p "${BLUE}[•] Download:${NC} $TITLE"; if [ -x "$BB" ]; then "$BB" wget -O "$DEST" "$URL" >/dev/null 2>&1 || curl -L "$URL" -o "$DEST" || return 1; "$BB" unzip -o "$DEST" -d "$DIR" >/dev/null 2>&1 || { p "${RED}[!] Gagal extract module.${NC}"; return 1; }; else curl -L "$URL" -o "$DEST" || return 1; unzip -o "$DEST" -d "$DIR" >/dev/null 2>&1 || { p "${RED}[!] unzip tidak tersedia.${NC}"; return 1; }; fi; p "${GREEN}[✓] Module siap: $DIR${NC}"; }
run_script(){ ID="$1"; NAME="$2"; need_daemon; [ -n "$ID" ] || { p 'Isi ID module.'; return 1; }; DIR="$MODULE_DIR/$ID"; [ -d "$DIR" ] || get_mod "$ID" || return 1; send_cmd "export PATH=/data/local/tmp/neon-core/bin:\$PATH; F=\$(find '$DIR' -name '$NAME' 2>/dev/null | head -n 1); if [ -n \"\$F\" ]; then sh \"\$F\"; else echo '[!] File $NAME tidak ditemukan'; exit 1; fi"; }
install_engine(){ need_daemon; need_dirs; p "${BLUE}[1/6] Menyiapkan engine...${NC}"; send_cmd 'rm -rf /data/local/tmp/neon-core; mkdir -p /data/local/tmp/neon-core/bin /data/local/tmp/neon-work /sdcard/Download/NeonEngine /sdcard/Download/NeonEngine/dump /sdcard/Download/NeonEngine/log /sdcard/Download/NeonEngine/apk /sdcard/Download/NeonEngine/media /sdcard/Download/NeonEngine/report' || return 1; p "${BLUE}[2/6] Memasang tool shell...${NC}"; send_cmd '[ -f /sdcard/Download/busybox ] || { echo "[!] File pendukung belum ada"; exit 1; }; cp /sdcard/Download/busybox /data/local/tmp/neon-core/bin/busybox 2>/dev/null || cat /sdcard/Download/busybox > /data/local/tmp/neon-core/bin/busybox; chmod 755 /data/local/tmp/neon-core/bin/busybox; /data/local/tmp/neon-core/bin/busybox --help >/dev/null 2>&1 || { echo "[!] Tool gagal jalan"; exit 1; }; echo "[✓] Tool OK"' || return 1; p "${BLUE}[3/6] Mengaktifkan applet...${NC}"; send_cmd 'cd /data/local/tmp/neon-core/bin && /data/local/tmp/neon-core/bin/busybox --install -s /data/local/tmp/neon-core/bin && echo "[✓] Applet OK"' || return 1; p "${BLUE}[4/6] Membuat environment...${NC}"; send_cmd 'printf "%s\n" "export PATH=\"/data/local/tmp/neon-core/bin:\$PATH\"" "export TMPDIR=\"/data/local/tmp\"" "export NEON_HOME=\"/data/local/tmp/neon-core\"" "export NEON_OUT=\"/sdcard/Download/NeonEngine\"" > /data/local/tmp/neon-core/env.sh; chmod 755 /data/local/tmp/neon-core/env.sh; echo "[✓] Env OK"' || return 1; p "${BLUE}[5/6] Membuat launcher...${NC}"; send_cmd 'printf "%s\n" "#!/system/bin/sh" "BB=\"/data/local/tmp/neon-core/bin/busybox\"" "ENV=\"/data/local/tmp/neon-core/env.sh\"" "[ -x \"\$BB\" ] || { echo \"[!] Engine belum terpasang\"; exit 1; }" "export PATH=\"/data/local/tmp/neon-core/bin:\$PATH\"" "[ -f \"\$ENV\" ] && . \"\$ENV\"" "if [ \"\${1:-shell}\" = \"test\" ]; then command -v busybox; command -v wget; command -v unzip; command -v find; exit 0; fi" "if [ \"\${1:-shell}\" = \"run\" ]; then shift; exec \"\$BB\" sh -c \"\$*\"; fi" "exec \"\$BB\" sh" > /data/local/tmp/neon; chmod 755 /data/local/tmp/neon; printf "%s\n" "#!/system/bin/sh" "sh /data/local/tmp/neon \"\$@\"" > /sdcard/Download/neon; chmod 755 /sdcard/Download/neon 2>/dev/null || true; echo "[✓] Launcher OK"' || return 1; p "${BLUE}[6/6] Test final...${NC}"; refresh || true; send_cmd 'export PATH=/data/local/tmp/neon-core/bin:$PATH; command -v busybox; command -v wget; command -v unzip; echo "[✓] Engine siap"' || return 1; }
status(){ if daemon_alive; then p "${GREEN}[✓] Engine aktif${NC}"; send_cmd 'id; getprop ro.product.model; getprop ro.build.version.release'; else p "${RED}[!] Engine belum aktif${NC}"; fi; }
doctor(){ p "NEON DOCTOR"; hr; p "Command neon : $(command -v neon 2>/dev/null || echo tidak ada)"; p "Web folder   : $WEB"; p "BusyBox      : $([ -x "$BB" ] && echo siap || echo tidak ada)"; p "curl         : $(command -v curl 2>/dev/null || echo tidak ada)"; p "unzip        : $(command -v unzip 2>/dev/null || echo tidak ada)"; p "Termux API   : $(command -v termux-battery-status 2>/dev/null && echo siap || echo opsional)"; if daemon_alive; then p "Engine       : aktif"; else p "Engine       : belum aktif"; fi; }
features(){ cat <<EOF
Interface/API: neon api, neon api-stop, neon api-status, neon web, neon web-stop, neon web-status, neon panel
Status: neon test, neon doctor, neon install, neon tools, neon termuxapi, neon features
Module: neon refresh, neon modules, neon search kata, neon info id, neon get id, neon exec id, neon agresif id, neon del id
Shell Bridge: neon shell "cmd", neon run "cmd", neon busybox "cmd", neon toybox "cmd"
Android CLI: neon pm "args", neon am "args", neon cmd "args", neon dumpsys "args", neon settings "args", neon input "args"
Device: neon device, neon battery, neon storage, neon memory, neon cpu, neon thermal, neon props, neon uptime, neon services, neon top, neon processes
Apps: neon apps, neon userapps, neon sysapps, neon appinfo package, neon app-start package, neon app-stop package, neon backupapk package, neon appops package, neon package-path package
Media/Input: neon screenshot, neon record 10, neon tap x y, neon swipe x1 y1 x2 y2 durasi, neon text teks, neon key kode
Network: neon net, neon dns, neon iproute, neon ping host
Display: neon wm-size, neon wm-density, neon wm-reset, neon anim-off, neon anim-normal, neon brightness 120, neon trim-cache
Logs/Report: neon report, neon logerr, neon logsave, neon logcat-tail, neon bugmini, neon open-folder
Termux API: neon termux-battery, neon termux-wifi, neon notify teks, neon clipboard teks
EOF
}
tools(){ p "Tools lokal:"; for t in curl unzip awk sed grep tr cut head tail sort wc; do command -v "$t" >/dev/null 2>&1 && p "[✓] $t" || p "[ ] $t"; done; p "Tools engine:"; need_daemon; send_cmd 'export PATH=/data/local/tmp/neon-core/bin:$PATH; for t in busybox wget unzip find sh sed awk grep pm am cmd dumpsys settings logcat screencap screenrecord input wm; do command -v $t >/dev/null 2>&1 && echo "[✓] $t" || echo "[ ] $t"; done'; }
termuxapi(){ p "Termux API opsional:"; for t in termux-battery-status termux-wifi-connectioninfo termux-clipboard-set termux-notification termux-open; do command -v "$t" >/dev/null 2>&1 && p "[✓] $t" || p "[ ] $t"; done; }
device(){ need_daemon; send_cmd 'echo "Brand   : $(getprop ro.product.brand)"; echo "Model   : $(getprop ro.product.model)"; echo "Device  : $(getprop ro.product.device)"; echo "Android : $(getprop ro.build.version.release)"; echo "SDK     : $(getprop ro.build.version.sdk)"; echo "ABI     : $(getprop ro.product.cpu.abi)"'; }
report(){ need_daemon; send_cmd 'mkdir -p /sdcard/Download/NeonEngine/report; getprop > /sdcard/Download/NeonEngine/report/props.txt; dumpsys battery > /sdcard/Download/NeonEngine/report/battery.txt; dumpsys meminfo > /sdcard/Download/NeonEngine/report/meminfo.txt; df -h > /sdcard/Download/NeonEngine/report/storage.txt; logcat -d | tail -n 400 > /sdcard/Download/NeonEngine/report/logcat_tail.txt; echo "[✓] Report tersimpan di /sdcard/Download/NeonEngine/report"'; }
make_api(){
need_dirs
SELF="$(command -v neon 2>/dev/null || printf '%s' "$0")"
cat > "$CGI/api" <<'API_EOF'
#!/data/data/com.termux/files/usr/bin/sh
printf 'Content-Type: text/plain; charset=utf-8\n'
printf 'Access-Control-Allow-Origin: *\n'
printf 'Access-Control-Allow-Methods: GET, POST, OPTIONS\n'
printf 'Access-Control-Allow-Headers: Content-Type\n'
printf 'Cache-Control: no-store\n'
printf '\n'
NEON='__CLIENT__'
METHOD="${REQUEST_METHOD:-GET}"
[ "$METHOD" = "OPTIONS" ] && exit 0
RAW="${QUERY_STRING:-}"
if [ "$METHOD" = "POST" ]; then
  BODY="$(cat 2>/dev/null || true)"
  [ -n "$BODY" ] && RAW="${RAW:+$RAW&}$BODY"
fi
urldecode(){
  _v=$(printf '%s' "$1" | sed 's/+/ /g; s/%20/ /g; s/%2F/\//g; s/%2f/\//g; s/%3A/:/g; s/%3a/:/g; s/%7C/|/g; s/%7c/|/g; s/%3D/=/g; s/%3d/=/g; s/%26/\\&/g; s/%22/\"/g; s/%27/'"'"'/g')
  printf '%s' "$_v"
}
param(){
  _key="$1"
  printf '%s\n' "$RAW" | tr '&' '\n' | sed -n "s/^${_key}=//p" | head -n 1 | while IFS= read -r _x; do urldecode "$_x"; done
}
ACT="$(param act)"; [ -n "$ACT" ] || ACT="$(param action)"
ID="$(param id)"
Q="$(param q)"
PKG="$(param pkg)"
CMD_IN="$(param cmd)"
SEC="$(param sec)"
X="$(param x)"; Y="$(param y)"
X1="$(param x1)"; Y1="$(param y1)"; X2="$(param x2)"; Y2="$(param y2)"; DUR="$(param dur)"
TXT="$(param text)"
KEY="$(param key)"
HOST_IN="$(param host)"
LEVEL="$(param level)"
printf 'NEON_API_RESPONSE
'
printf 'act=%s
' "${ACT:-home}"
printf 'route=/cgi-bin/api
'
printf 'method=%s
' "$METHOD"
printf 'time=%s
' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo unknown)"
printf -- '--- output ---
'
case "$ACT" in
  apihealth|health) echo 'API online'; "$NEON" web-status ;;
  status|test) "$NEON" test ;;
  doctor) "$NEON" doctor ;;
  install) "$NEON" install ;;
  features) "$NEON" features ;;
  tools) "$NEON" tools ;;
  termuxapi) "$NEON" termuxapi ;;
  webstatus|api-status) "$NEON" web-status ;;
  refresh) "$NEON" refresh ;;
  modules) "$NEON" modules ;;
  search) "$NEON" search "$Q" ;;
  info) "$NEON" info "$ID" ;;
  get) "$NEON" get "$ID" ;;
  exec) "$NEON" exec "$ID" ;;
  agresif) "$NEON" agresif "$ID" ;;
  del) "$NEON" del "$ID" ;;
  device|deviceinfo) "$NEON" device ;;
  battery) "$NEON" battery ;;
  storage) "$NEON" storage ;;
  memory|mem) "$NEON" memory ;;
  cpu) "$NEON" cpu ;;
  thermal) "$NEON" thermal ;;
  props) "$NEON" props ;;
  uptime) "$NEON" uptime ;;
  services) "$NEON" services ;;
  top) "$NEON" top ;;
  processes) "$NEON" processes ;;
  apps) "$NEON" apps ;;
  userapps) "$NEON" userapps ;;
  sysapps) "$NEON" sysapps ;;
  appinfo) "$NEON" appinfo "$PKG" ;;
  appstart|app-start) "$NEON" app-start "$PKG" ;;
  appstop|app-stop) "$NEON" app-stop "$PKG" ;;
  backupapk) "$NEON" backupapk "$PKG" ;;
  appops) "$NEON" appops "$PKG" ;;
  packagepath|package-path) "$NEON" package-path "$PKG" ;;
  shell) "$NEON" shell "$CMD_IN" ;;
  busybox) "$NEON" busybox "$CMD_IN" ;;
  toybox) "$NEON" toybox "$CMD_IN" ;;
  pm) "$NEON" pm "$CMD_IN" ;;
  am) "$NEON" am "$CMD_IN" ;;
  cmd) "$NEON" cmd "$CMD_IN" ;;
  dumpsys) "$NEON" dumpsys "$CMD_IN" ;;
  settings) "$NEON" settings "$CMD_IN" ;;
  input) "$NEON" input "$CMD_IN" ;;
  run) "$NEON" run "$CMD_IN" ;;
  screenshot) "$NEON" screenshot ;;
  record) "$NEON" record "${SEC:-10}" ;;
  tap) "$NEON" tap "$X" "$Y" ;;
  swipe) "$NEON" swipe "$X1" "$Y1" "$X2" "$Y2" "${DUR:-300}" ;;
  text) "$NEON" text "$TXT" ;;
  key) "$NEON" key "$KEY" ;;
  clipboardset|clipboard) "$NEON" clipboard "$TXT" ;;
  notify) "$NEON" notify "$TXT" ;;
  net) "$NEON" net ;;
  dns) "$NEON" dns ;;
  iproute) "$NEON" iproute ;;
  ping) "$NEON" ping "${HOST_IN:-8.8.8.8}" ;;
  wifiapi) "$NEON" termux-wifi ;;
  wmsize|wm-size) "$NEON" wm-size ;;
  wmdensity|wm-density) "$NEON" wm-density ;;
  wmreset|wm-reset) "$NEON" wm-reset ;;
  animoff|anim-off) "$NEON" anim-off ;;
  animnormal|anim-normal) "$NEON" anim-normal ;;
  brightness) "$NEON" brightness "$LEVEL" ;;
  trimcache|trim-cache) "$NEON" trim-cache ;;
  logerr) "$NEON" logerr ;;
  logsave) "$NEON" logsave ;;
  logcattail|logcat-tail) "$NEON" logcat-tail ;;
  report) "$NEON" report ;;
  bugmini) "$NEON" bugmini ;;
  openfolder|open-folder|lastreport) "$NEON" open-folder ;;
  ''|home) echo 'Gunakan act=apihealth. Contoh POST shell: curl -X POST http://127.0.0.1:8787/cgi-bin/api -d act=shell --data-urlencode "cmd=pm list packages"' ;;
  *) echo "Action tidak dikenal: $ACT"; echo 'Gunakan act=apihealth, deviceinfo, shell, apps, appinfo, screenshot, logsave, report, modules.' ;;
esac
API_EOF
# Ganti marker path neon setelah heredoc dibuat. Heredoc wajib quoted supaya REQUEST_METHOD/QUERY_STRING tidak dieksekusi saat generator berjalan.
sed -i "s#__CLIENT__#$SELF#g" "$CGI/api"
chmod 755 "$CGI/api"
cp "$CGI/api" "$CGI/api.cgi" 2>/dev/null || true
cp "$CGI/api" "$CGI/api.sh" 2>/dev/null || true
chmod 755 "$CGI/api.cgi" "$CGI/api.sh" 2>/dev/null || true
[ -s "$CGI/api" ] || { p "${RED}[!] Gagal membuat API route: $CGI/api kosong.${NC}"; return 1; }
}
web_running(){ [ -x "$BB" ] || return 1; "$BB" wget -q -O - "http://127.0.0.1:$WEB_PORT/" >/dev/null 2>&1; }
web_start(){ need_dirs; [ -f "$WEB/index.html" ] || { p "${RED}[!] webgui.html belum terpasang. Jalankan ulang neon-engine.sh dari ZIP.${NC}"; return 1; }; [ -x "$BB" ] || { p "${RED}[!] Tool web belum siap. Jalankan ulang installer.${NC}"; return 1; }; "$BB" --list 2>/dev/null | grep -qx httpd || { p "${RED}[!] httpd tidak tersedia di tool web.${NC}"; return 1; }; make_api || return 1; if web_running; then p "${GREEN}[✓] Web Control sudah aktif${NC}"; else "$BB" httpd -p "127.0.0.1:$WEB_PORT" -h "$WEB" >/dev/null 2>&1 || { p "${RED}[!] Gagal menjalankan web server.${NC}"; return 1; }; sleep 1; fi; URL="http://127.0.0.1:$WEB_PORT"; p "${GREEN}[✓] Neon Local API:${NC} $URL"; if command -v termux-open-url >/dev/null 2>&1; then termux-open-url "$URL" >/dev/null 2>&1 || true; fi; }
web_stop(){ if [ -x "$BB" ] && "$BB" --list 2>/dev/null | grep -qx pkill; then "$BB" pkill -f "httpd.*127.0.0.1:$WEB_PORT" 2>/dev/null || true; else pkill -f "httpd.*127.0.0.1:$WEB_PORT" 2>/dev/null || true; fi; p "${GREEN}[✓] Web server dihentikan jika sebelumnya aktif.${NC}"; }
web_status(){ if web_running; then p "${GREEN}[✓] Web Control aktif di http://127.0.0.1:$WEB_PORT${NC}"; else p "${YELLOW}[!] Web Control belum aktif. Jalankan: neon web${NC}"; fi; }
pause(){ printf '\nEnter untuk lanjut...'; read _ || true; }
text_panel(){ while true; do clear 2>/dev/null || true; p "${MAG}NEON CORE TERMUX PANEL${NC}"; hr; p "${WHITE}1.${NC} Web Control"; p "${WHITE}2.${NC} Doctor"; p "${WHITE}3.${NC} Install / Repair"; p "${WHITE}4.${NC} Module"; p "${WHITE}5.${NC} Device"; p "${WHITE}6.${NC} Apps"; p "${WHITE}7.${NC} Media"; p "${WHITE}8.${NC} Logs"; p "${WHITE}9.${NC} Run Command"; p "${WHITE}0.${NC} Keluar"; hr; printf 'Pilih: '; read A || exit 0; case "$A" in 1) web_start; pause ;; 2) doctor; pause ;; 3) install_engine; pause ;; 4) modules; pause ;; 5) device; pause ;; 6) send_cmd 'pm list packages | head -n 80'; pause ;; 7) send_cmd 'mkdir -p /sdcard/Download/NeonEngine/media; screencap -p /sdcard/Download/NeonEngine/media/screenshot_$(date +%s).png; echo "[✓] Screenshot tersimpan"'; pause ;; 8) report; pause ;; 9) printf 'Command: '; read C; [ -n "$C" ] && send_cmd "export PATH=/data/local/tmp/neon-core/bin:\$PATH; $C"; pause ;; 0) exit 0 ;; esac; done; }
case "${1:-help}" in
  test|status) status ;; doctor) doctor ;; install|repair) install_engine ;; panel|menu) text_panel ;; api|web|server|ui) web_start ;; api-stop|web-stop|stop-web) web_stop ;; api-status|web-status) web_status ;;
  refresh) refresh ;; modules) modules ;; search) shift; search_mod "$*" ;; info) info_mod "${2:-}" ;; get) get_mod "${2:-}" ;; exec) run_script "${2:-}" execute.sh ;; agresif) run_script "${2:-}" agresif.sh ;; del) run_script "${2:-}" del.sh ;;
  device) device ;; battery) need_daemon; send_cmd 'dumpsys battery' ;; storage) need_daemon; send_cmd 'export PATH=/data/local/tmp/neon-core/bin:$PATH; df -h' ;; memory) need_daemon; send_cmd 'cat /proc/meminfo | head -n 30; dumpsys meminfo | head -n 80' ;; cpu) need_daemon; send_cmd 'cat /proc/cpuinfo | head -n 80' ;; thermal) need_daemon; send_cmd 'for f in /sys/class/thermal/thermal_zone*/temp; do echo "$f: $(cat $f 2>/dev/null)"; done | head -n 40' ;; props) need_daemon; send_cmd 'getprop | head -n 220' ;; uptime) need_daemon; send_cmd 'uptime; cat /proc/uptime' ;; services) need_daemon; send_cmd 'service list | head -n 160' ;; top) need_daemon; send_cmd 'top -b -n 1 2>/dev/null | head -n 80 || toybox top -b -n 1 | head -n 80' ;; processes) need_daemon; send_cmd 'ps -A 2>/dev/null | head -n 160 || toybox ps -A | head -n 160' ;;
  apps) need_daemon; send_cmd 'pm list packages' ;; userapps) need_daemon; send_cmd 'pm list packages -3' ;; sysapps) need_daemon; send_cmd 'pm list packages -s' ;; appinfo) need_daemon; send_cmd "dumpsys package ${2:-} | head -n 220" ;; app-start) need_daemon; send_cmd "monkey -p ${2:-} 1" ;; app-stop) need_daemon; send_cmd "am force-stop ${2:-}; echo '[✓] Force stop dikirim'" ;; backupapk) need_daemon; send_cmd "export PATH=/data/local/tmp/neon-core/bin:\$PATH; mkdir -p /sdcard/Download/NeonEngine/apk; P='${2:-}'; APK=\$(pm path \$P | head -n1 | sed 's/package://'); [ -f \"\$APK\" ] && cp \"\$APK\" /sdcard/Download/NeonEngine/apk/\$P.apk && echo '[✓] APK tersimpan' || echo '[!] APK tidak bisa dibaca'" ;; appops) need_daemon; send_cmd "cmd appops get ${2:-} 2>/dev/null || appops get ${2:-} 2>/dev/null" ;; package-path) need_daemon; send_cmd "pm path ${2:-}" ;;
  screenshot) need_daemon; send_cmd 'mkdir -p /sdcard/Download/NeonEngine/media; screencap -p /sdcard/Download/NeonEngine/media/screenshot_$(date +%s).png; echo "[✓] Screenshot tersimpan"' ;; record) need_daemon; send_cmd "mkdir -p /sdcard/Download/NeonEngine/media; timeout ${2:-10} screenrecord /sdcard/Download/NeonEngine/media/record_\$(date +%s).mp4; echo '[✓] Record selesai'" ;; tap) need_daemon; send_cmd "input tap ${2:-0} ${3:-0}" ;; swipe) need_daemon; send_cmd "input swipe ${2:-0} ${3:-0} ${4:-0} ${5:-0} ${6:-300}" ;; text) shift; need_daemon; send_cmd "input text '$*'" ;; key) need_daemon; send_cmd "input keyevent ${2:-3}" ;;
  net) need_daemon; send_cmd 'ip addr 2>/dev/null || ifconfig; getprop | grep -i dns' ;; dns) need_daemon; send_cmd 'getprop | grep -i dns' ;; iproute) need_daemon; send_cmd 'ip route 2>/dev/null || route -n 2>/dev/null' ;; ping) need_daemon; send_cmd "ping -c 4 ${2:-8.8.8.8}" ;;
  wm-size) need_daemon; send_cmd 'wm size' ;; wm-density) need_daemon; send_cmd 'wm density' ;; wm-reset) need_daemon; send_cmd 'wm size reset; wm density reset; echo "[✓] Display reset"' ;; anim-off) need_daemon; send_cmd 'settings put global window_animation_scale 0; settings put global transition_animation_scale 0; settings put global animator_duration_scale 0; echo "[✓] Animasi dimatikan"' ;; anim-normal) need_daemon; send_cmd 'settings put global window_animation_scale 1; settings put global transition_animation_scale 1; settings put global animator_duration_scale 1; echo "[✓] Animasi normal"' ;; brightness) need_daemon; if [ -n "${2:-}" ]; then send_cmd "settings put system screen_brightness ${2:-120}; echo '[✓] Brightness dikirim'"; else send_cmd 'settings get system screen_brightness'; fi ;; trim-cache) need_daemon; send_cmd 'pm trim-caches 999G; echo "[✓] Trim cache dikirim"' ;;
  report) report ;; logerr) need_daemon; send_cmd 'logcat -d | grep -i -E "error|crash|fatal|exception" | tail -n 200' ;; logsave) need_daemon; send_cmd 'mkdir -p /sdcard/Download/NeonEngine/log; logcat -d > /sdcard/Download/NeonEngine/log/logcat.txt; echo "[✓] Log tersimpan"' ;; logcat-tail) need_daemon; send_cmd 'logcat -d | tail -n 250' ;; bugmini) need_daemon; send_cmd 'mkdir -p /sdcard/Download/NeonEngine/report; dumpsys activity crashes > /sdcard/Download/NeonEngine/report/crashes.txt; dumpsys dropbox --print | tail -n 220 > /sdcard/Download/NeonEngine/report/dropbox_tail.txt; echo "[✓] Bug mini tersimpan"' ;; open-folder) if command -v termux-open >/dev/null 2>&1; then termux-open /sdcard/Download/NeonEngine; else p '/sdcard/Download/NeonEngine'; fi ;;
  termuxapi) termuxapi ;; termux-battery) command -v termux-battery-status >/dev/null 2>&1 && termux-battery-status || p 'Install Termux:API dulu.' ;; termux-wifi) command -v termux-wifi-connectioninfo >/dev/null 2>&1 && termux-wifi-connectioninfo || p 'Install Termux:API dulu.' ;; notify) shift; command -v termux-notification >/dev/null 2>&1 && termux-notification --title 'Neon Core' --content "$*" || p 'Install Termux:API dulu.' ;; clipboard) shift; command -v termux-clipboard-set >/dev/null 2>&1 && printf '%s' "$*" | termux-clipboard-set && p '[✓] Clipboard diset' || p 'Install Termux:API dulu.' ;;
  tools) tools ;; features) features ;; shell) shift; need_daemon; send_cmd "export PATH=/data/local/tmp/neon-core/bin:\$PATH; $*" ;; busybox) shift; need_daemon; send_cmd "/data/local/tmp/neon-core/bin/busybox $*" ;; toybox) shift; need_daemon; send_cmd "toybox $*" ;; pm) shift; need_daemon; send_cmd "pm $*" ;; am) shift; need_daemon; send_cmd "am $*" ;; cmd) shift; need_daemon; send_cmd "cmd $*" ;; dumpsys) shift; need_daemon; send_cmd "dumpsys $*" ;; settings) shift; need_daemon; send_cmd "settings $*" ;; input) shift; need_daemon; send_cmd "input $*" ;; run) shift; need_daemon; send_cmd "export PATH=/data/local/tmp/neon-core/bin:\$PATH; $*" ;; help|-h|--help) p 'Neon Core Engine'; p 'Mulai: neon doctor && neon install && neon api'; p 'ZIP install: curl -L https://neonmagisk.my.id/neon-engine.zip -o neon-engine.zip && unzip -o neon-engine.zip && chmod +x neon-engine.sh && sh neon-engine.sh'; p 'Shell bridge: neon shell "pm list packages", neon busybox "ls -la", neon toybox "ps -A"'; p 'API: neon api, neon api-status, neon api-stop'; p 'Lihat fitur: neon features' ;;
  *) need_daemon; send_cmd "export PATH=/data/local/tmp/neon-core/bin:\$PATH; $*" ;;
esac
CLIENT_EOF
chmod 755 "$CLIENT" || fail 'Gagal membuat command neon.'
say "${G}[✓] Command neon siap${N}"
line
say "${B}[7/7] Evaluasi awal...${N}"
if "$CLIENT" doctor >/dev/null 2>&1; then say "${G}[✓] Doctor siap${N}"; else say "${Y}[!] Doctor belum sempurna, cek dengan: neon doctor${N}"; fi
line
say "${G}[✓] SETUP SELESAI${N}"
say ""
say "${C}Mulai:${N}"
say "${W}    neon doctor${N}"
say "${W}    neon install${N}"
say "${W}    neon api${N}"
say ""
say "${C}API lokal:${N}"
say "${W}    http://127.0.0.1:8787/cgi-bin/api?act=apihealth${N}"
say ""
say "${C}Panel teks:${N}"
say "${W}    neon panel${N}"
